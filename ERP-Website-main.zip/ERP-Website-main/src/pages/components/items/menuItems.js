export const menuItems = [
  {
    title: 'Solutions',
    submenu: [
      {
        title: 'ERP',
        url: 'ERP',
      },
      {
        title: 'POS',
        url: 'POS',
      },
      {
        title: 'PAYROLL',
        url: 'PAYROLL',
      },
      {
        title: 'CRM',
        url: 'CRM',
      },
      {
        title: 'REAL ESTATE CRM',
        url: 'CRM',
      },
    ],
  },
  // {
  //   title: 'About us',
  // },
  {
    title: 'Pricing',
    url: 'pricing',
  },
  // {
  //   title: 'Become a partner',
  // },
];
