const BaseURL = {
    BASE_URL: `${process.env.REACT_APP_BASE_URL}`,
};

export const API_CONSTANTS = {
    ENQUIRE_FORM: `${BaseURL.BASE_URL}/ContactUs/EnquiryForm`,
    SCHEDULE_CALL: `${BaseURL.BASE_URL}/ContactUs/ScheduleCall`,
    GET_SOLUTIONS: `${BaseURL.BASE_URL}/ContactUs/GetSolutionMaster`,
    // ENQUIRE_FORM: 'http://development2.promena.in/api/ContactUs/EnquiryForm',
    // SCHEDULE_CALL: 'http://development2.promena.in/api/ContactUs/ScheduleCall',
    // GET_SOLUTIONS: 'http://development2.promena.in/api/ContactUs/GetSolutionMaster',
};
export const API_METHODS = {
    GET: 'GET',
    POST: 'POST',
    DELETE: 'DELETE',
    UPDATE: 'UPDATE',
    PUT: 'PUT'
};

