import React, { useState } from 'react';
import logo from '../../assets/images/logo.png';
import './header.scss';
import { HashLink } from 'react-router-hash-link';
import { Link } from 'react-router-dom';
import MenuItems from '../components/MenuItems';
import { menuItems } from '../components/items/menuItems';
import { NavLink, useNavigate } from 'react-router-dom';

const Header = () => {
    const naviagte = useNavigate();
    const [isNavExpanded, setIsNavExpanded] = useState(false)
    const [isOpen, setOpen] = useState(false);

    const closeMenu = () => {
        setIsNavExpanded(false);
    }

    const handleClickScroll = () => {
        window.scrollTo(0, 0);
    };

    const toggleDropdown = () => setOpen(!isOpen);

    const handleErp = () => {
        naviagte('/ERP');
        window.scrollTo(0, 0);
        setIsNavExpanded(false);
        setOpen(false);
    }
    const handlePos = () => {
        naviagte('/POS');
        window.scrollTo(0, 0);
        setIsNavExpanded(false);
        setOpen(false);
    }
    const handlePayroll = () => {
        naviagte('/PAYROLL');
        window.scrollTo(0, 0);
        setIsNavExpanded(false);
        setOpen(false);
    }
    const handleCrm = () => {
        naviagte('/CRM');
        window.scrollTo(0, 0);
        setIsNavExpanded(false);
        setOpen(false);
    }

    return (
        <div>
            <div className='header fixed-header fixed-top' id='navbar'>
                <nav className='navigation'>
                    <a className='header-name' onClick={closeMenu}>
                        <Link to='/' onClick={handleClickScroll}>
                            <img src={logo} alt='' />
                        </Link>
                    </a>
                    <div className={
                        isNavExpanded ? 'header-menu expanded' : 'header-menu'
                    }>
                        <div className='header__menus'>
                            <div className='header__left-menu'>
                                <nav className='mobile-header-left'>
                                    <ul className="menus">
                                        {menuItems.map((menu, index) => {
                                            const depthLevel = 0;
                                            return (
                                                <MenuItems
                                                    items={menu}
                                                    key={index}
                                                    depthLevel={depthLevel}
                                                />
                                            );
                                        })}
                                        <button className='sign-up'>
                                            <NavLink to='schedule-a-demo'>
                                                SCHEDULE A DEMO
                                            </NavLink>
                                        </button>
                                    </ul>
                                </nav>
                                <ul className='mobile-header'>
                                    <li>
                                        <div className='dropdown2'>
                                            <div className='dropdown2-header' onClick={toggleDropdown}>
                                                Solutions
                                                <i className='fa fa-chevron-down icon' />
                                            </div>
                                            <div className={`dropdown2-body ${isOpen && 'open'}`}>
                                                <div className="dropdown2-item">
                                                    <a onClick={handleErp}>
                                                        ERP
                                                    </a>
                                                </div>
                                                <div className="dropdown2-item">
                                                    <a onClick={handlePos}>
                                                        POS
                                                    </a>
                                                </div>
                                                <div className="dropdown2-item">
                                                    <a onClick={handlePayroll}>
                                                        PAYROLL
                                                    </a>
                                                </div>
                                                <div className="dropdown2-item">
                                                    <a onClick={handleCrm}>
                                                        CRM
                                                    </a>
                                                </div>
                                                <div className="dropdown2-item">
                                                    <a onClick={handleCrm}>
                                                        REAL ESTATE CRM
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li onClick={() => {
                                        setIsNavExpanded(!isNavExpanded);
                                    }}>
                                        <NavLink to='/pricing'>Pricing
                                        </NavLink>
                                    </li>
                                    {/* <li>
                                        <HashLink smooth to='' style={{ cursor: 'pointer' }}>
                                            Become a partner
                                        </HashLink>
                                    </li> */}
                                    <li className='mobile'>
                                        <button className='sign-up' onClick={() => {
                                            setIsNavExpanded(!isNavExpanded);
                                        }}>
                                            <NavLink to='/schedule-a-demo'>SCHEDULE A DEMO
                                            </NavLink>
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <button onClick={() => {
                        setIsNavExpanded(!isNavExpanded);
                    }}
                        className='hamburger'>
                        <svg xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5" viewBox="0 0 20 20" fill="white">
                            <path fillRule="evenodd"
                                d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM9 15a1 1 0 011-1h6a1 1 0 110 2h-6a1 1 0 01-1-1z"
                                clipRule="evenodd" />
                        </svg>
                    </button>
                </nav>
            </div>
        </div>
    )
}

export default Header;