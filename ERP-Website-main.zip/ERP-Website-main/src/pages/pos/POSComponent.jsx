import React from 'react';
import './POSStyles.scss';
import bgbanner from '../../assets/images/subpages/banner-common.jpg';
import icon from '../../assets/images/subpages/icon.png';
import POSBanner from '../../assets/images/subpages/pos/banner.png';
import POSSales from '../../assets/images/subpages/pos/sales.png';
import POSReports from '../../assets/images/subpages/pos/reports.png';
import tab1 from '../../assets/images/subpages/pos/Service.jpg';
import tab2 from '../../assets/images/subpages/pos/company support.jpg';
import tab3 from '../../assets/images/subpages/pos/constant updates.jpg';
import Slide from 'react-reveal/Slide';
import { Tab, TabPanel, Tabs, TabList } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';

const POSComponent = () => {
    return (
        <div className='pos'>
            <div className='pos__container'>
                <div className='pos__banner'
                    style={{
                        backgroundImage: `url(${bgbanner})`,
                        backgroundSize: 'cover', backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'center top'
                    }}>
                    <div className='pos__banner__container'>
                        <div className='pos__banner__sections'>
                            <div className='pos__banner__left'>
                                <div className='pos__banner__left__content'>
                                    <Slide left>
                                        <h2>With Akountant increase your sales</h2>
                                        <div className='pos__banner__left__content__line'></div>
                                        <p>This amazing software will manage your business better and compete with large national chains. Using the software Akountant, serve your customers faster, invoice electronically, manage several accounts at the same time, print your sales receipts, manage your business credits, and control your inventory.</p>
                                    </Slide>
                                </div>
                            </div>
                            <div className='pos__banner__right'>
                                <div className='pos__banner__right__image'>
                                    <Slide right>
                                        <img src={POSBanner} alt='ERP_Banner' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='pos__features'>
                    <div className='pos__features__container'>
                        <div className='pos__features__sections'>
                            <div className='pos__features__left'>
                                <div className='pos__features__left__content'>
                                    <Slide bottom>
                                        <h2>Manage your sales easily with Akountant POS</h2>
                                        <div className='pos__features__left__content__line'></div>
                                        <h5>Akountant POS is highly convenient to use and you can access it from any Android device.</h5>
                                    </Slide>
                                    <div className='pos__features__left__content__points'>
                                        <div className='pos__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Improve the administration of your business by taking exact control of your sales and inventories of your products.</p>
                                            </Slide>
                                        </div>
                                        <div className='pos__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>It saves costs. Due to its android-based feature, it is compatible with a large number of tablets and its interface is easy to use.</p>
                                            </Slide>
                                        </div>
                                        <div className='pos__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>You can operate it from anywhere. Through its cloud technology, you can access your products at any time.</p>
                                            </Slide>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className='pos__features__right'>
                                <div className='pos__features__right__image'>
                                    <Slide left>
                                        <img src={POSSales} alt='ERP_Features' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                        <div className='pos__features__sections1'>
                            <div className='pos__features__left'>
                                <div className='pos__features__left__content'>
                                    <Slide bottom>
                                        <h2>Configure your products and access reports from the web platform</h2>
                                        <div className='pos__features__left__content__line'></div>
                                    </Slide>
                                    <div className='pos__features__left__content__points'>
                                        <div className='pos__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>You can use it in all your branches and businesses and also you can configure the profiles of your users and assign permissions.</p>
                                            </Slide>
                                        </div>
                                        <div className='pos__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Obtain sales reports for the day or for periods, best-selling products.</p>
                                            </Slide>
                                        </div>
                                        <div className='pos__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Send tickets by mail so that your client can issue their invoice directly from your web portal.</p>
                                            </Slide>
                                        </div>
                                        <div className='pos__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Sales control of simple or compound products, inventories, discounts and electronic invoicing.</p>
                                            </Slide>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className='pos__features__right'>
                                <div className='pos__features__right__image'>
                                    <Slide right>
                                        <img src={POSReports} alt='ERP_Features' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='pos__real'>
                    <div className='pos__real__container'>
                        <div className='pos__real__sections'>
                            <div className='pos__real__heading'>
                                <h2>Why entrust your business to Akountant?</h2>
                                <div className='pos__real__heading__line'></div>
                                <h5>Akountant is much more than Point of Sale software.</h5>
                            </div>
                            <div className='pos__real__tabs'>
                                <Tabs>
                                    <TabList>
                                        <Tab>
                                            <div className='pos__real__tabs__tab'>
                                                <div className='pos__real__tabs__tab__section'>
                                                    <h4>We are always at your service</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                        <Tab>
                                            <div className='pos__real__tabs__tab'>
                                                <div className='pos__real__tabs__tab__section'>
                                                    <h4>You will get a responsible company support</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                        <Tab>
                                            <div className='pos__real__tabs__tab'>
                                                <div className='pos__real__tabs__tab__section'>
                                                    <h4>Constant updates</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                    </TabList>
                                    <TabPanel>
                                        <div className='pos__real__tabs__tabpanel'>
                                            <div className='pos__real__tabs__tabpanel__section'>
                                                <div className='pos__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab1} alt='ERP_Features' />
                                                    </Slide>
                                                </div>
                                                <div className='pos__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>We are always at your service</h3>
                                                        <p>Your point of sale will be the program that you will use all day and that is why we know that it is important to be able to count on us in case of any doubt, our commitment is to provide you with exceptional technical support at all times.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                    <TabPanel>
                                        <div className='pos__real__tabs__tabpanel'>
                                            <div className='pos__real__tabs__tabpanel__section'>
                                                <div className='pos__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab2} alt='ERP_Features' />
                                                    </Slide>
                                                </div>
                                                <div className='pos__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>You will get a responsible company support</h3>
                                                        <p>With professionals holding fine years of experience in software development, you have the support of a serious and responsible company.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                    <TabPanel>
                                        <div className='pos__real__tabs__tabpanel'>
                                            <div className='pos__real__tabs__tabpanel__section'>
                                                <div className='pos__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab3} alt='ERP_Features' />
                                                    </Slide>
                                                </div>
                                                <div className='pos__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>Constant updates</h3>
                                                        <p>Every day we work to improve the program looking for how it can help you more in your business, that's why we constantly publish updates to keep you at the forefront.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                </Tabs>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default POSComponent;