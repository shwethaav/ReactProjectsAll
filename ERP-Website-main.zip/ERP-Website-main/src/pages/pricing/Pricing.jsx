import React, { useState } from 'react';
import './Pricing.scss';
import dedicate from '../../assets/images/dedicated_support.svg';
import sync from '../../assets/images/sync_icon.svg';
import { useNavigate } from 'react-router-dom';
import Slide from 'react-reveal/Slide';

const Pricing = () => {
    const navigate = useNavigate();
    const [isNavExpanded, setIsNavExpanded] = useState(false)

    const handleContactNavigate = () => {
        navigate('/contact-us')
        window.scroll(0, 0);
    }

    return (
        <div className='price'>
            <div className='price__container'>
                <div className='price__sections'>
                    <div className='price__heading'>
                        <div className='price__heading__card'>
                            <h4>Why buy AKOUNTANT License?</h4>
                            <div className='price__heading__card__section'>
                                <div className='price__heading__card__section__left'>
                                    <img src={dedicate} alt='dedicate' />
                                    <div className='price__heading__card__section__left__content'>
                                        <h2>Dedicated Support</h2>
                                        <p>Get priority support, for all your AKOUNTANT related queries and
                                            issues.</p>
                                    </div>
                                </div>
                                <div className='price__heading__card__section__right'>
                                    <img src={sync} alt='sync' />
                                    <div className='price__heading__card__section__right__content'>
                                        <h2>Sync Support</h2>
                                        <p>Sync between all your devices, with our team setting it up
                                            completely for you.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='price__plan'>
                        <div className='price__plan__section'>
                            <div className='price__plan__heading'>
                                <h3>Select a Plan</h3>
                            </div>
                            <div className='price__plan__sections'>
                                <div className='price__plan__left'>
                                    <div className='price__plan__left__card'>
                                        <Slide bottom>
                                            <div className='price__plan__left__card__heading'>
                                                <h2>Basic Plan</h2>
                                                <span>Valid for 1 Year</span>
                                            </div>
                                        </Slide>
                                        <Slide bottom>
                                            <div className='price__plan__left__card__section'>
                                                <h5>Only Desktop</h5>
                                                <span>₹ 2499</span>
                                                <h6>₹ 1799</h6>
                                                <button onClick={handleContactNavigate}>Let's Talk</button>
                                            </div>
                                        </Slide>
                                    </div>
                                </div>
                                <div className='price__plan__right'>
                                    <div className='price__plan__right__card'>
                                        <Slide bottom>
                                            <div className='price__plan__right__card__heading'>
                                                <h2>Saver Plan</h2>
                                                <span>Valid for 5 Year</span>
                                            </div>
                                        </Slide>
                                        <Slide bottom>
                                            <div className='price__plan__right__card__section'>
                                                <h5>Only Desktop</h5>
                                                <span>₹ 7499</span>
                                                <h6>₹ 4999</h6>
                                                <button onClick={handleContactNavigate}>Let's Talk</button>
                                            </div>
                                        </Slide>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Pricing;