import React from 'react';
import './footer.scss';
import { HashLink } from 'react-router-hash-link';
import { Link } from 'react-router-dom';
import { NavLink } from 'react-router-dom';

const Footer = () => {

    const handleClickScroll = () => {
        window.scrollTo(0, 0);
    };


    return (
        <div className='footer'>
            <div className='footer__container'>
                <div className='footer__sections'>
                    <div className='footer__left'>
                        <div className='footer__left__heading'>
                            <h3>Connect with us</h3>
                        </div>
                        <div className='footer__left__links'>
                            <ul>
                                <li><HashLink>Facebook</HashLink></li>
                                <li><HashLink>Twitter</HashLink></li>
                                <li><HashLink>Instagram</HashLink></li>
                                <li><HashLink>Linkedin</HashLink></li>
                            </ul>
                        </div>
                    </div>
                    <div className='footer__center1'>
                        <div className='footer__center1__heading'>
                            <h3>Key competence</h3>
                        </div>
                        <div className='footer__center1__links'>
                            <ul>
                                <li><HashLink>Advanced billing</HashLink></li>
                                <li><HashLink>Analysis capabilities</HashLink></li>
                                <li><HashLink>Quick reporting</HashLink></li>
                                <li><HashLink>Personalization</HashLink></li>
                            </ul>
                        </div>
                    </div>
                    <div className='footer__center2'>
                        <div className='footer__center2__heading'>
                            <h3>Features</h3>
                        </div>
                        <div className='footer__center2__links'>
                            <ul>
                                <li><HashLink>Barcode Generator</HashLink></li>
                                <li><HashLink>Reconciliation</HashLink></li>
                                <li><HashLink>Easy & Global Search</HashLink></li>
                                <li><HashLink>Sales & Purchase Management</HashLink></li>
                                <li><HashLink>GST Compliance Invoices & Expenses</HashLink></li>
                                <li><HashLink>Automatic Mailing and SMS Alert</HashLink></li>
                            </ul>
                        </div>
                    </div>
                    <div className='footer__center3'>
                        <div className='footer__center3__heading'>
                            <h3>Solutions</h3>
                        </div>
                        <div className='footer__center3__links'>
                            <ul>
                                <li><NavLink to='/ERP'>ERP</NavLink></li>
                                <li><NavLink to='/POS'>POS</NavLink></li>
                                <li><NavLink to='/PAYROLL'>PAYROLL</NavLink></li>
                                <li><NavLink to='CRM'>CRM</NavLink></li>
                                <li><NavLink>REAL ESTATE CRM</NavLink></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div className='footer__bottom'>
                    <div className='footer__bottom__line'></div>
                    <p>&#169; Copyright AKOUNTANT Pvt. Ltd. 2023</p>
                </div>
            </div>
        </div>
    )
}

export default Footer;