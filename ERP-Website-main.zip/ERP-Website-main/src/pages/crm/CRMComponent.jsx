import React from 'react';
import './CRMStyles.scss';
import bgbanner from '../../assets/images/subpages/banner-common.jpg';
import icon from '../../assets/images/subpages/icon.png';
import image1 from '../../assets/images/subpages/crm/image1.png';
import image2 from '../../assets/images/subpages/crm/image2.png';
import image3 from '../../assets/images/subpages/crm/image3.png';
import tab1 from '../../assets/images/subpages/crm/maximum productivity.jpg';
import tab2 from '../../assets/images/subpages/crm/necessary control.jpg';
import tab3 from '../../assets/images/subpages/crm/focus on results.jpg';
import Slide from 'react-reveal/Slide';
import { Tab, TabPanel, Tabs, TabList } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';

const CRMComponent = () => {
    return (
        <div className='crm'>
            <div className='crm__container'>
                <div className='crm__banner'
                    style={{
                        backgroundImage: `url(${bgbanner})`,
                        backgroundSize: 'cover', backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'center top'
                    }}>
                    <div className='crm__banner__container'>
                        <div className='crm__banner__sections'>
                            <div className='crm__banner__left'>
                                <div className='crm__banner__left__content'>
                                    <Slide left>
                                        <h2>All-in-One CRM Software</h2>
                                        <div className='crm__banner__left__content__line'></div>
                                        <p>Customer Relationship Management goes beyond a platform or software, as it encompasses the entire process used by startups, SMEs, and large companies to manage and analyze customer interactions. Indeed, the CRM allows you to anticipate needs and desires, optimize profitability, increase sales, and customize campaigns to attract new leads.</p>
                                    </Slide>
                                </div>
                            </div>
                            <div className='crm__banner__right'>
                                <div className='crm__banner__right__image'>
                                    <Slide right>
                                        <img src={image1} alt='CRM_Banner' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='crm__features'>
                    <div className='crm__features__container'>
                        <div className='crm__features__sections'>
                            <div className='crm__features__left'>
                                <div className='crm__features__left__content'>
                                    <Slide bottom>
                                        <h2>Why to choose Akountant CRM platform?</h2>
                                        <div className='crm__features__left__content__line'></div>
                                    </Slide>
                                    <div className='crm__features__left__content__points'>
                                        <div className='crm__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Actively track and manage customer information.</p>
                                            </Slide>
                                        </div>
                                        <div className='crm__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Connect your entire team on any device.</p>
                                            </Slide>
                                        </div>
                                        <div className='crm__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Capture customer emails intelligently.</p>
                                            </Slide>
                                        </div>
                                        <div className='crm__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Simplify repetitive tasks so you can more effectively follow up on leads.</p>
                                            </Slide>
                                        </div>
                                        <div className='crm__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Provides instant recommendations and insights.</p>
                                            </Slide>
                                        </div>
                                        <div className='crm__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Expand and customize as your business grows.</p>
                                            </Slide>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className='crm__features__right'>
                                <div className='crm__features__right__image'>
                                    <Slide left>
                                        <img src={image2} alt='CRM_Features' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                        <div className='crm__features__sections1'>
                            <div className='crm__features__left'>
                                <div className='crm__features__left__content'>
                                    {/* <h2>Configure your products and access reports from the web platform</h2>
                                    <div className='crm__features__left__content__line'></div> */}
                                    <div className='crm__features__left__content__points'>
                                        <div className='crm__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>CRM helps your business get rid of outdated processes and manual effort so your business can move forward. The platform organizes accounts and contacts in an accessible way, in real time, speeding up and simplifying the sales process.</p>
                                            </Slide>
                                        </div>
                                        <div className='crm__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Instead of relying on sticky note reminders or spending all your time poring over spreadsheets, you can send leads to your sales team quickly and easily. That way, all team members will work with up-to-date information about customers and their interactions with the company. With data in view and easy access to it, it's easier to collaborate and increase productivity.</p>
                                            </Slide>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className='crm__features__right'>
                                <div className='crm__features__right__image'>
                                    <Slide right>
                                        <img src={image3} alt='CRM_Features' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='crm__real'>
                    <div className='crm__real__container'>
                        <div className='crm__real__sections'>
                            <div className='crm__real__heading'>
                                <h2>Benefits of Akountant CRM</h2>
                                <div className='crm__real__heading__line'></div>
                            </div>
                            <div className='crm__real__tabs'>
                                <Tabs>
                                    <TabList>
                                        <Tab>
                                            <div className='crm__real__tabs__tab'>
                                                <div className='crm__real__tabs__tab__section'>
                                                    <h4>Maximum productivity</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                        <Tab>
                                            <div className='crm__real__tabs__tab'>
                                                <div className='crm__real__tabs__tab__section'>
                                                    <h4>Necessary control</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                        <Tab>
                                            <div className='crm__real__tabs__tab'>
                                                <div className='crm__real__tabs__tab__section'>
                                                    <h4>Focus on results</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                    </TabList>
                                    <TabPanel>
                                        <div className='crm__real__tabs__tabpanel'>
                                            <div className='crm__real__tabs__tabpanel__section'>
                                                <div className='crm__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab1} alt='CRM_Features' />
                                                    </Slide>
                                                </div>
                                                <div className='crm__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>Maximum productivity</h3>
                                                        <p>No chaos - just streamlined workflows. Deals, contacts, and tasks are created automatically. This saves time and protects your business processes from errors.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                    <TabPanel>
                                        <div className='crm__real__tabs__tabpanel'>
                                            <div className='crm__real__tabs__tabpanel__section'>
                                                <div className='crm__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab2} alt='CRM_Features' />
                                                    </Slide>
                                                </div>
                                                <div className='crm__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>Necessary control</h3>
                                                        <p>All communications with customers are just one click away. Phone conversations with clients are automatically attached to the deal. Therefore, you are always aware of all the nuances of communication with customers.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                    <TabPanel>
                                        <div className='crm__real__tabs__tabpanel'>
                                            <div className='crm__real__tabs__tabpanel__section'>
                                                <div className='crm__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab3} alt='CRM_Features' />
                                                    </Slide>
                                                </div>
                                                <div className='crm__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>Focus on results</h3>
                                                        <p>High-quality analytics for all the indicators you need. Track the number and quality of calls, ad ROI, employee performance, and other business-critical data.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                </Tabs>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default CRMComponent;