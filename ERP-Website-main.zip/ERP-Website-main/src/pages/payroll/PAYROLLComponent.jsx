import React from 'react';
import './PAYROLLStyles.scss';
import bgbanner from '../../assets/images/subpages/banner-common.jpg';
import icon from '../../assets/images/subpages/icon.png';
import Banner from '../../assets/images/subpages/payroll/banner.png'
import PrePayroll from '../../assets/images/subpages/payroll/pre-payroll.png'
import Calculate from '../../assets/images/subpages/payroll/calculate.png'
import tab1 from '../../assets/images/subpages/payroll/declared taxes.jpg'
import tab2 from '../../assets/images/subpages/payroll/fair price.jpg'
import tab3 from '../../assets/images/subpages/payroll/expert assistance.jpg'
import Slide from 'react-reveal/Slide';
import { Tab, TabPanel, Tabs, TabList } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';

const PayrollComponent = () => {
    return (
        <div className='payroll'>
            <div className='payroll__container'>
                <div className='payroll__banner'
                    style={{
                        backgroundImage: `url(${bgbanner})`,
                        backgroundSize: 'cover', backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'center top'
                    }}>
                    <div className='payroll__banner__container'>
                        <div className='payroll__banner__sections'>
                            <div className='payroll__banner__left'>
                                <div className='payroll__banner__left__content'>
                                    <Slide left>
                                        <h2>Payroll Management Software</h2>
                                        <div className='payroll__banner__left__content__line'></div>
                                        <p>Akountant is the integration that allows you to configure and maintain your payroll, using the information contained in files, incidents and other modules.</p>
                                        <p>Due to the advanced integration in our payroll system, you will be able to speed up the processing of pre-payroll, calculations, dispersions, reports and other activities related to payroll.</p>
                                    </Slide>
                                </div>
                            </div>
                            <div className='payroll__banner__right'>
                                <div className='payroll__banner__right__image'>
                                    <Slide right>
                                        <img src={PrePayroll} alt='Payroll_Banner' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='payroll__features'>
                    <div className='payroll__features__container'>
                        <div className='payroll__features__sections'>
                            <div className='payroll__features__left'>
                                <div className='payroll__features__left__content'>
                                    <Slide bottom>
                                        <h2>Generate the calculations for your pre-payroll
                                            {/* with the certainty you need */}
                                        </h2>
                                    </Slide>
                                    <div className='payroll__features__left__content__line'></div>
                                    <div className='payroll__features__left__content__points'>
                                        <div className='payroll__features__left__content__point'>
                                            {/* <img src={icon} alt='icon' /> */}
                                            <Slide bottom>
                                                <p>Apply the issues of your choice and have them automatically submitted to Akountant. It integrates incidents such as vacations, bonuses, commissions, absenteeism and disabilities.</p>
                                            </Slide>
                                        </div>
                                    </div>
                                    <Slide bottom>
                                        <h2>Distribute the receipts to your collaborators</h2>
                                        <div className='payroll__features__left__content__line'></div>
                                    </Slide>
                                    <div className='payroll__features__left__content__points'>
                                        <div className='payroll__features__left__content__point'>
                                            {/* <img src={icon} alt='icon' /> */}
                                            <Slide bottom>
                                                <p>Our software automatically distributes the payslips created in the Akountant payroll system in the mailbox of your collaborators. No need to send one by one. </p>
                                            </Slide>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className='payroll__features__right'>
                                <div className='payroll__features__right__image'>
                                    <Slide left>
                                        <img src={Banner} alt='PrePayroll' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                        <div className='payroll__features__sections1'>
                            <div className='payroll__features__left'>
                                <div className='payroll__features__left__content'>
                                    <Slide bottom>
                                        <h2>Akountant calculates professionally </h2>
                                        <div className='payroll__features__left__content__line'></div>
                                    </Slide>
                                    <div className='payroll__features__left__content__points'>
                                        <div className='payroll__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Akountant payroll calculates professionally and accurately, without errors or extra costs. The Akountant integration allows you to increase confidence in your payroll calculation and avoid errors during its processing.</p>
                                            </Slide>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className='payroll__features__right'>
                                <div className='payroll__features__right__image'>
                                    <Slide right>
                                        <img src={Calculate} alt='Calculate' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='payroll__real'>
                    <div className='payroll__real__container'>
                        <div className='payroll__real__sections'>
                            <div className='payroll__real__heading'>
                                <h2>Payroll is made simple with Akountant</h2>
                                <h5>Akountant is your perfect destination if you want to get full-service payroll, automatic tax filings, and employee benefits in one place. Our software is designed keeping the needs of businesses in mind.</h5>
                                <h3>Enjoy the Benefits:</h3>
                                <div className='payroll__real__heading__line'></div>
                            </div>
                            <div className='payroll__real__tabs'>
                                <Tabs>
                                    <TabList>
                                        <Tab>
                                            <div className='payroll__real__tabs__tab'>
                                                <div className='payroll__real__tabs__tab__section'>
                                                    <h4>Declared taxes</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                        <Tab>
                                            <div className='payroll__real__tabs__tab'>
                                                <div className='payroll__real__tabs__tab__section'>
                                                    <h4>The fair price</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                        <Tab>
                                            <div className='payroll__real__tabs__tab'>
                                                <div className='payroll__real__tabs__tab__section'>
                                                    <h4>Expert assistance</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                    </TabList>
                                    <TabPanel>
                                        <div className='payroll__real__tabs__tabpanel'>
                                            <div className='payroll__real__tabs__tabpanel__section'>
                                                <div className='payroll__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab1} alt='Declared taxes' />
                                                    </Slide>
                                                </div>
                                                <div className='payroll__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>Declared taxes</h3>
                                                        <p>With automatic filings for local and state payroll taxes, you can focus on running your business.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                    <TabPanel>
                                        <div className='payroll__real__tabs__tabpanel'>
                                            <div className='payroll__real__tabs__tabpanel__section'>
                                                <div className='payroll__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab2} alt='The fair price' />
                                                    </Slide>
                                                </div>
                                                <div className='payroll__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>The fair price</h3>
                                                        <p>All the business owners can run payroll and more, for one flat price with no hidden fees.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                    <TabPanel>
                                        <div className='payroll__real__tabs__tabpanel'>
                                            <div className='payroll__real__tabs__tabpanel__section'>
                                                <div className='payroll__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab3} alt='Expert assistance' />
                                                    </Slide>
                                                </div>
                                                <div className='payroll__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>Expert assistance</h3>
                                                        <p>We have payroll service specialists to help you manage the payroll software every step of the way.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                </Tabs>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div >
    )
}

export default PayrollComponent;