import React, { useState, useEffect } from 'react';
import './Schedule.scss';
import bgImage from '../../assets/images/banner/demo1.jpg';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Slide from 'react-reveal/Slide';
import { ScheduleCall, GetSolutions } from '../utils/apicalls';
import { regex } from '../utils/regex';
import Confirm from '../components/confirmModal/confirm';
import Loader from '../components/loader';

const Schedule = () => {
    const [dropdown, setDropdown] = useState();
    const [firstName, setFirstName] = useState();
    const [lastName, setLastName] = useState();
    const [workEmail, setWorkEmail] = useState();
    const [company, setCompany] = useState();
    const [industry, setIndustry] = useState();
    const [selectedDropdown, setSelectedDropdown] = useState();
    const [phoneNumber, setPhoneNumber] = useState();
    const [requirements, setRequirements] = useState();
    const [isShowLoader, setIsShowLoader] = useState(false);
    const [alertText, setAlertText] = useState();
    const [showConfirmModal, setShowConfirmModal] = useState(false);
    const [showConfirmModal1, setShowConfirmModal1] = useState(false);

    useEffect(() => {
        getSolutionsDropdown();
    }, []);

    const getSolutionsDropdown = () => {
        GetSolutions((res) => {
            setDropdown(res);
        })
    }

    const validateEmail = (Email) => {
        const emailRegex = regex.emailRegex;
        return emailRegex.test(Email);
    };

    const validateNumber = (Number) => {
        const phoneRegex = regex.phoneRegex;
        return phoneRegex.test(Number);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const payload = {
            firstName: firstName,
            lastName: lastName,
            phoneNumer: phoneNumber,
            workEmail: workEmail,
            requirements: requirements,
            company: company,
            industry: industry,
            solutionId: selectedDropdown
        }
        console.log(payload)
        if (payload) {
            if (firstName && lastName && workEmail && industry && phoneNumber && company && selectedDropdown) {
                if (validateEmail(workEmail)) {
                    if (phoneNumber.length === 10 && validateNumber(phoneNumber)) {
                        ScheduleCall((res) => {
                            const { message, statusCode } = res;
                            if (statusCode === 200) {
                                setIsShowLoader(false);
                                setShowConfirmModal(true);
                                setShowConfirmModal1(true);
                                setAlertText(message);
                                // window.location.reload();
                            } else {
                                setShowConfirmModal(false);
                                setShowConfirmModal1(true);
                                setIsShowLoader(false);
                                setAlertText('error');
                            }
                        }, payload)
                    } else {
                        setAlertText('Enter Valid Phone Number');
                        setShowConfirmModal(false);
                        setShowConfirmModal1(true);
                        setIsShowLoader(false);
                    }
                } else {
                    setAlertText('Enter Valid Email');
                    setShowConfirmModal(false);
                    setShowConfirmModal1(true);
                    setIsShowLoader(false);
                }
            } else {
                setAlertText('Fill All The Required Fields');
                setShowConfirmModal(false);
                setShowConfirmModal1(true);
                setIsShowLoader(false);
            }
        }
    }

    const handleConfirm = () => {
        window.location.reload();
        setShowConfirmModal(true);
    }

    return (
        <div className='demo'>
            <div className='demo__container'>
                <div className='demo__section'>
                    {/* <div className='demo__section__bg' style={{
                        backgroundImage: `url(${bgImage})`,
                        backgroundSize: 'cover', backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'center top'
                    }}> */}
                    <div className='demo__section__bg'>
                        <div className='demo__section__bg__image'>
                            <img src={bgImage} alt='demo-banner' />
                            <h1>Schedule A Demo</h1>
                        </div>
                        <div className='demo__section-main'>
                            <div className='demo__sections'>
                                <div className='demo__left'>
                                    <div className='demo__left__form'>
                                        <Slide bottom>
                                            <div className='demo__left__form__heading'>
                                                {/* <h2>Get a demo</h2> */}
                                                <h2>Schedule now to avail  one week of free trail</h2>
                                            </div>
                                            <form>
                                                <div className='demo__left__form__inputs flex'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="First Name"
                                                        placeholder="First Name"
                                                        multiline
                                                        required={true}
                                                        onChange={(event) => setFirstName(event.target.value)}
                                                    />
                                                </div>
                                                <div className='demo__left__form__inputs flex'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="Last Name"
                                                        placeholder="Last Name"
                                                        multiline
                                                        required={true}
                                                        onChange={(event) => setLastName(event.target.value)}
                                                    />
                                                </div>
                                                <div className='demo__left__form__inputs'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="Work Email"
                                                        placeholder="Work Email"
                                                        multiline
                                                        required={true}
                                                        onChange={(event) => setWorkEmail(event.target.value)}
                                                    />
                                                </div>
                                                <div className='demo__left__form__inputs'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="Company"
                                                        placeholder="Company"
                                                        multiline
                                                        required={true}
                                                        onChange={(event) => setCompany(event.target.value)}
                                                    />
                                                </div>
                                                <div className='demo__left__form__inputs flex'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="Industry"
                                                        placeholder="Industry"
                                                        multiline
                                                        required={true}
                                                        onChange={(event) => setIndustry(event.target.value)}
                                                    />
                                                </div>
                                                <div className='demo__left__form__inputs flex'>
                                                    {/* <TextField
                                                    id="outlined-textarea"
                                                    label="Solutions *"
                                                    placeholder="Solutions *"
                                                    multiline
                                                /> */}
                                                    <FormControl sx={{ m: 1, minWidth: 120 }}>
                                                        <InputLabel id="demo-simple-select-helper-label">Solutions *</InputLabel>
                                                        <Select
                                                            labelId="demo-simple-select-helper-label"
                                                            id="demo-simple-select-helper"
                                                            // value={age}
                                                            label="Solutions *"
                                                            onChange={(event) => setSelectedDropdown(event.target.value)}
                                                            defaultValue={selectedDropdown}
                                                        >
                                                            {/* <MenuItem value={0}><em> -- Select Solution -- </em></MenuItem> */}
                                                            {dropdown?.length && dropdown?.map((val, index) => {
                                                                return (
                                                                    <MenuItem key={index} value={val.solutionId}>{val.solutionType}</MenuItem>
                                                                )
                                                            })}
                                                            {/* <MenuItem value=""><em>None</em></MenuItem>
                                                            <MenuItem value={1}>ERP</MenuItem>
                                                            <MenuItem value={2}>POS</MenuItem>
                                                            <MenuItem value={3}>PAYROLL</MenuItem>
                                                            <MenuItem value={4}>CRM</MenuItem>
                                                            <MenuItem value={5}>REAL ESTATE CRM</MenuItem> */}
                                                        </Select>
                                                        {/* <FormHelperText>With label + helper text</FormHelperText> */}
                                                    </FormControl>
                                                </div>
                                                <div className='demo__left__form__inputs'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="Phone No"
                                                        placeholder="Phone No"
                                                        multiline
                                                        onChange={(event) => setPhoneNumber(event.target.value)}
                                                        required={true}
                                                        type="number"
                                                        pattern="[0-9]*"
                                                        inputProps={{ maxLength: 10, minLength: 10 }}
                                                    // onInput={(e) => {
                                                    //     e.target.value = Math.max(0, parseInt(e.target.value)).toString().slice(0, 10)
                                                    // }}
                                                    />
                                                </div>
                                                <div className='demo__left__form__inputs'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="Your Requirements"
                                                        placeholder="Your Requirements"
                                                        multiline
                                                        rows={3}
                                                        onChange={(event) => setRequirements(event.target.value)}
                                                    />
                                                </div>
                                                <div className='demo__left__form__button'>
                                                    <button onClick={(e) => handleSubmit(e)}>Submit</button>
                                                </div>
                                            </form>
                                        </Slide>
                                    </div>
                                </div>
                                <div className='demo__right'>
                                    <div className='demo__right__section'>
                                        <Slide bottom>
                                            <h2>Drive Efficiency & Growth With Akountant Solutions </h2>
                                            <h3>Schedule for a demo now and get a free 1 week trail of our solutions.</h3>
                                            <h4>Let us help in taking your business to the next level.</h4>
                                        </Slide>
                                        <div className='demo__right__section__points'>
                                            <Slide bottom>
                                                <h2>What Can Akountant Do?</h2>
                                            </Slide>
                                            <div className='demo__right__section__point'>
                                                <Slide bottom>
                                                    <i className='fa fa-check' />
                                                    <p>Quickly & easily create barcodes.</p>
                                                </Slide>
                                            </div>
                                            <div className='demo__right__section__point'>
                                                <Slide bottom>
                                                    <i className='fa fa-check' />
                                                    <p>Verify data sets to match your records.</p>
                                                </Slide>
                                            </div>
                                            <div className='demo__right__section__point'>
                                                <Slide bottom>
                                                    <i className='fa fa-check' />
                                                    <p>Optimize your supply chain & improve profitability.</p>
                                                </Slide>
                                            </div>
                                            <div className='demo__right__section__point'>
                                                <Slide bottom>
                                                    <i className='fa fa-check' />
                                                    <p>Create professional invoices.</p>
                                                </Slide>
                                            </div>
                                            <div className='demo__right__section__point'>
                                                <Slide bottom>
                                                    <i className='fa fa-check' />
                                                    <p>Easy integration of automatic mailing & SMS alert.</p>
                                                </Slide>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {showConfirmModal && (
                <Confirm buttonText={'OK'} isCancelRequired={false} confirmTitle={alertText}
                    onConfirm={() => { handleConfirm() }}
                    onCancel={() => { setShowConfirmModal(false) }} />
            )}
            {showConfirmModal1 && (
                <Confirm buttonText={'OK'} isCancelRequired={false} confirmTitle={alertText}
                    onConfirm={() => { setShowConfirmModal1(false) }}
                    onCancel={() => { setShowConfirmModal1(false) }} />
            )}
            {isShowLoader ? <Loader /> : null}
        </div>
    )
}

export default Schedule;