import React, { useEffect } from 'react';
import './home.scss';
import CRM from '../../assets/images/banner/CRM1.jpg';
import ERP from '../../assets/images/banner/ERP2.jpg';
import Payroll from '../../assets/images/banner/Payroll.jpg';
import POS from '../../assets/images/banner/POS.jpg';
import cloud1 from '../../assets/images/cloud based/CRM.svg';
import cloud2 from '../../assets/images/cloud based/Pos.svg';
import cloud3 from '../../assets/images/cloud based/Payroll.svg';
import cloud4 from '../../assets/images/cloud based/ERP.svg';
import cloud5 from '../../assets/images/cloud based/real estate crm.svg';
import capabilities1 from '../../assets/images/key capabilities/Advanced billing.svg';
import capabilities2 from '../../assets/images/key capabilities/analysis.svg';
import capabilities3 from '../../assets/images/key capabilities/reports.svg';
import capabilities4 from '../../assets/images/key capabilities/personalization.svg';
import features1 from '../../assets/images/key features/barcode.svg';
import features2 from '../../assets/images/key features/reconcillation.svg';
import features3 from '../../assets/images/key features/global search.svg';
import features4 from '../../assets/images/key features/sales & purchase management.svg';
import features5 from '../../assets/images/key features/gst.svg';
import features6 from '../../assets/images/key features/automatic mail.svg';
import why1 from '../../assets/images/why akountant/financial management.svg';
import why2 from '../../assets/images/why akountant/clound based.svg';
import why3 from '../../assets/images/why akountant/customer relationship.svg';
import why4 from '../../assets/images/why akountant/hardware.svg';
import why5 from '../../assets/images/why akountant/business inntelligence.svg';
import why6 from '../../assets/images/why akountant/personalized package.svg';
import why7 from '../../assets/images/why akountant/real estate management.svg';
import real1 from '../../assets/images/real estate mamangement/effectiveness.svg';
import real2 from '../../assets/images/real estate mamangement/intuitive system.svg';
import real3 from '../../assets/images/real estate mamangement/crm.svg';
import real4 from '../../assets/images/real estate mamangement/effective support.svg';
import real5 from '../../assets/images/real estate mamangement/pocket friendly.svg';
import real6 from '../../assets/images/real estate mamangement/commercials.svg';
import lead from '../../assets/images/banner/Home-Svg.svg';
import { Helmet } from 'react-helmet-async';
import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import Slide from 'react-reveal/Slide';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Navigation } from "swiper";
import 'swiper/css';
import 'swiper/css/bundle';
import FAQs from '../components/faq/faq';
import { useNavigate } from 'react-router-dom';

const Home = (props) => {
    const navigate = useNavigate();

    useEffect(() => {
        document.title = props.title;
    });

    const handleDemo = () => {
        navigate('/schedule-a-demo');
        window.scroll(0, 0);
    }

    return (
        <>
            <Helmet>
                <title>AKOUNTANT | Home</title>
                <meta name="description" content="AKOUNTANT | Home" />
                <meta name="keyWords" content="AKOUNTANT | Home" />
            </Helmet>
            <div className='home'>
                <div className='home__container'>
                    <div className='banner'>
                        <div className='banner__container'>
                            <Carousel showThumbs={false} showArrows={false}
                                transitionTime={2} showStatus={false}
                                autoPlay={true} infiniteLoop={true} >
                                <div className='banner__slider'>
                                    <img src={CRM} alt='home_banner' />
                                    <div className='banner__content'>
                                        <div className='banner__content__main'>
                                            {/* <Fade top>
                                            <h1>For your Services</h1>
                                        </Fade> */}
                                            {/* <Slide left> */}
                                            <h2>CRM</h2>
                                            <p>CRM (Customer Relationship Management) is the art of creating, developing and maintaining a privileged relationship with each of your customers.
                                            </p>
                                            {/* </Slide> */}
                                        </div>
                                    </div>
                                </div>
                                <div className='banner__slider'>
                                    <img src={ERP} alt='home_banner' />
                                    <div className='banner__content'>
                                        <div className='banner__content__main'>
                                            {/* <Slide left> */}
                                            <h2>ERP</h2>
                                            <p>ERP is a software package that allows you to manage all of a company's operational processes by integrating several management functions.
                                            </p>
                                            {/* </Slide> */}
                                        </div>
                                    </div>
                                </div>
                                <div className='banner__slider'>
                                    <img src={Payroll} alt='home_banner' />
                                    <div className='banner__content'>
                                        <div className='banner__content__main'>
                                            {/* <Slide left> */}
                                            <h2>PAYROLL</h2>
                                            <p>The payroll is defined as the total gross remuneration of employees of the establishment.
                                            </p>
                                            {/* </Slide> */}
                                        </div>
                                    </div>
                                </div>
                                <div className='banner__slider'>
                                    <img src={POS} alt='home_banner' />
                                    <div className='banner__content'>
                                        <div className='banner__content__main'>
                                            {/* <Slide left> */}
                                            <h2>POS</h2>
                                            <p>Point of sale (POS), an essential part of a point of purchase, is where a customer makes payment for goods or services and where sales taxes may become payable.
                                            </p>
                                            {/* </Slide> */}
                                        </div>
                                    </div>
                                </div>
                            </Carousel>
                        </div>
                    </div>
                    <div className='cloud'>
                        <div className='cloud__container'>
                            <div className='cloud__header'>
                                <h2>Top Notch ERP Solution for Your Business Requirements</h2>
                            </div>
                            <div className='cloud__sections'>
                                <div className='cloud__section'>
                                    <img src={cloud1} alt='ERP' />
                                    <Slide bottom>
                                        <h3>ERP</h3>
                                        <p>Our innovative enterprise resource planning (ERP) software is a modern solution that effectively streamlines everyday work processes, meets regulatory standards, and accommodates the growth of the business.</p>
                                    </Slide>
                                </div>
                                <div className='cloud__section'>
                                    <img src={cloud2} alt='POS' />
                                    <Slide bottom>
                                        <h3>POS</h3>
                                        <p>Our POS system is highly intuitive and easy to install. You spend less training time, you depend less on specialized personnel for the training of operating personnel, and the software is currently very easy to use.</p>
                                    </Slide>
                                </div>
                                <div className='cloud__section'>
                                    <img src={cloud3} alt='Payroll' />
                                    <Slide bottom>
                                        <h3>Payroll</h3>
                                        <p>Akountant provides a comprehensive and interdisciplinary service that is responsible for solving each of your payroll management processes.</p>
                                    </Slide>
                                </div>
                                <div className='cloud__section'>
                                    <img src={cloud4} alt='CRM' />
                                    <Slide bottom>
                                        <h3>CRM</h3>
                                        <p>Akountant’s CRM functionality includes marketing functions for prospect acquisition, traceability of sales processes and centralization of service and support for greater effectiveness.</p>
                                    </Slide>
                                </div>
                                <div className='cloud__section'>
                                    <img src={cloud5} alt='REAL ESTATE CRM' />
                                    <Slide bottom>
                                        <h3>REAL ESTATE CRM</h3>
                                        <p>Real-Estate CRM designed to support developers, agents & fast growing marketplaces .It includes Inquiry Distribution, Inventory Management ,Marketing Automation and and caters to the multiple requirements of real estate agents and real estate firms.!</p>
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='Capabilities'>
                        <div className='Capabilities__container'>
                            <div className='Capabilities__header'>
                                <Slide top>
                                    <h2>Key competence of Akountant</h2>
                                </Slide>
                            </div>
                            <div className='Capabilities__sections'>
                                <div className='Capabilities__section'>
                                    <img src={capabilities1} alt='Advanced billing' />
                                    <Slide bottom>
                                        <h3>Advanced billing</h3>
                                        <p>Our most advanced ERP solution Akountant is capable of detecting and integrating the invoices received through a built-in automated scanning and detection solution. Likewise, they present an Invoice module with electronic signature.</p>
                                    </Slide>
                                </div>
                                <div className='Capabilities__section'>
                                    <img src={capabilities2} alt='Analysis capabilities' />
                                    <Slide bottom>
                                        <h3>Analysis capabilities</h3>
                                        <p>Our POS system is highly intuitive and easy to install. You spend less training time, you depend less on specialized personnel for the training of operating personnel, and the software is currently very easy to use.</p>
                                    </Slide>
                                </div>
                                <div className='Capabilities__section'>
                                    <img src={capabilities3} alt='Quick reporting' />
                                    <Slide bottom>
                                        <h3>Quick reporting</h3>
                                        <p>Simply Reporting by using akounting solution, custom Dashboard can be turned into suitable reports & identify your profitable way.</p>
                                    </Slide>
                                </div>
                                <div className='Capabilities__section'>
                                    <img src={capabilities4} alt='Personalization' />
                                    <Slide bottom>
                                        <h3>Personalization</h3>
                                        <p>The success of an ERP software is measured, to a large extent, by user satisfaction, which is why Akountant is critical as it offer maximum customization and an intuitive interface along with ease of creating new processes, menu options, new fields, and new screens.</p>
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='features'>
                        <div className='features__container'>
                            <div className='features__heading'>
                                <h2>Intriguing features present in Akountant</h2>
                            </div>
                            <div className='features__sections'>
                                <Swiper spaceBetween={50}
                                    // slidesPerView={3}
                                    // autoplay={{ delay: 3000 }}
                                    modules={[Autoplay, Navigation]}
                                    loop={Infinity}
                                    navigation={true}
                                    breakpoints={{
                                        "@0.00": {
                                            slidesPerView: 1,
                                            spaceBetween: 10,
                                        },
                                        "@0.75": {
                                            slidesPerView: 2,
                                            spaceBetween: 20,
                                        },
                                        "@1.00": {
                                            slidesPerView: 3,
                                            spaceBetween: 40,
                                        },
                                        "@1.50": {
                                            slidesPerView: 3,
                                            spaceBetween: 40,
                                        },
                                        "@1.75": {
                                            slidesPerView: 3,
                                            spaceBetween: 50,
                                        },
                                        "@2.0": {
                                            slidesPerView: 3,
                                            spaceBetween: 50,
                                        },
                                    }}>
                                    <SwiperSlide>
                                        <div className="features__section">
                                            <img
                                                src={features1}
                                                alt="Barcode Generator"
                                            />
                                            <div className="features__section__content">
                                                <Slide bottom>
                                                    <h3>Barcode Generator</h3>
                                                    <p>Quickly and easily create barcodes for a variety of applications, including retail, health care and pharmaceutical industries.</p>
                                                </Slide>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="features__section">
                                            <img
                                                src={features2}
                                                alt="Reconciliation"
                                            />
                                            <div className="features__section__content">
                                                <Slide bottom>
                                                    <h3>Reconciliation</h3>
                                                    <p>The reconciliation feature of Akountant compares the internal records with the external records and verifies that both sets of data match. </p>
                                                </Slide>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="features__section">
                                            <img
                                                src={features3}
                                                alt="Easy & Global Search"
                                            />
                                            <div className="features__section__content">
                                                <Slide bottom>
                                                    <h3>Easy & Global Search</h3>
                                                    <p>Speaking of searches, precisely the search interface presented by the ERP system must be clear to users, if it is easy to search and find data and documents, then on this side it guarantees a good experience.</p>
                                                </Slide>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="features__section">
                                            <img
                                                src={features4}
                                                alt="Sales & Purchase Management"
                                            />
                                            <div className="features__section__content">
                                                <Slide bottom>
                                                    <h3>Sales & Purchase Management</h3>
                                                    <p>With Akountant optimize your supply chain and improve your profitability by effectively coordinating the entire purchasing, sales, and warehouse management cycle.</p>
                                                </Slide>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="features__section">
                                            <img
                                                src={features5}
                                                alt="GST Compliance Invoices & Expenses"
                                            />
                                            <div className="features__section__content">
                                                <Slide bottom>
                                                    <h3>GST Compliance Invoices & Expenses</h3>
                                                    <p>Our software solution will help create professional invoices, receive updates and organize your expenses and receipts online.</p>
                                                </Slide>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="features__section">
                                            <img
                                                src={features6}
                                                alt="Automatic Mailing and SMS Alert"
                                            />
                                            <div className="features__section__content">
                                                <Slide bottom>
                                                    <h3>Automatic Mailing and SMS Alert</h3>
                                                    <p>Our automatic mailing and SMS alert is an ideal communication solution for professionals that wish to communicate with their contacts at needed moments.</p>
                                                </Slide>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                </Swiper>
                            </div>
                        </div>
                    </div>
                    <div className='why'>
                        <div className='why__container'>
                            <div className='why__header'>
                                <Slide top>
                                    <h2>Why you should consider Akountant?</h2>
                                </Slide>
                            </div>
                            <div className='why__sections'>
                                <div className='why__section'>
                                    <Slide bottom>
                                        <img src={why1} alt='Financial Management' />
                                    </Slide>
                                    <Slide bottom>
                                        <h3>Financial Management</h3>
                                        <p>Improve control of company assets, cash flow and accounting.</p>
                                    </Slide>
                                </div>
                                <div className='why__section'>
                                    <Slide bottom>
                                        <img src={why2} alt='CLOUD based accounting software –' />
                                    </Slide>
                                    <Slide bottom>
                                        <h3>CLOUD based accounting software</h3>
                                        <p>Works both online/offline</p>
                                    </Slide>
                                </div>
                                <div className='why__section'>
                                    <Slide bottom>
                                        <img src={why3} alt='Customer Relationship Management ' />
                                    </Slide>
                                    <Slide bottom>
                                        <h3>Customer Relationship Management </h3>
                                        <p>Provide better customer service and increase cross-sell and upsell opportunities.</p>
                                    </Slide>
                                </div>
                                <div className='why__section'>
                                    <Slide bottom>
                                        <img src={why4} alt='Hardware independent' />
                                    </Slide>
                                    <Slide bottom>
                                        <h3>Hardware independent</h3>
                                        <p>Runs on browser and aslso support ass the devices.</p>
                                    </Slide>
                                </div>
                                <div className='why__section'>
                                    <Slide bottom>
                                        <img src={why5} alt='Business intelligence' />
                                    </Slide>
                                    <Slide bottom>
                                        <h3>Business intelligence</h3>
                                        <p>Provide easy-to-use tools to help with business intelligence, reporting, and analysis needs.</p>
                                    </Slide>
                                </div>
                                <div className='why__section'>
                                    <Slide bottom>
                                        <img src={why6} alt='Personalized packages ' />
                                    </Slide>
                                    <Slide bottom>
                                        <h3>Personalized packages </h3>
                                        <p>you can choose any package of softwares according  to  your needs .</p>
                                    </Slide>
                                </div>
                                <div className='why__section'>
                                    <Slide bottom>
                                        <img src={why7} alt='Real Estate Management' />
                                    </Slide>
                                    <Slide bottom>
                                        <h3>Real Estate Management</h3>
                                        <p>With a very extensive knowledge of the market, the socio-economic context of the region, Akkountant is able to offer a reliable analysis of the viability of a business before the investor makes the decision to buy.</p>
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='sales'>
                        <div className='sales__container'>
                            <div className='sales__sections'>
                                <div className='sales__left'>
                                    <Slide left>
                                        {/* <img src={logo} className='sales__left__img1' alt='logo' /> */}
                                        <h2>Manage your Real Estate leads and sales with our dedicated CRM.</h2>
                                        <p>Our Real Estate CRM has multiple functionalities adapted and personalized to grow your business</p>
                                        {/* <img src={ratings} className='sales__left__img2' alt='ratings' /> */}
                                        <button onClick={handleDemo}>Get a Personalized Demo</button>
                                    </Slide>
                                </div>
                                <div className='sales__right'>
                                    <Slide right>
                                        <img src={lead} alt='lead' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='leads'>
                        <div className='leads__container'>
                            <div className='leads__header'>
                                {/* <h2>Manage your real estate leads and sales with our dedicated CRM:</h2> */}
                                {/* <h5>Our real estate CRM has multiple functionalities adapted and personalized to grow your business.</h5> */}
                                <Slide bottom>
                                    <h6>Here is how Akountant can help you sell more properties faster:</h6>
                                </Slide>
                            </div>
                            <div className='leads__sections'>
                                <div className='leads__section'>
                                    <Slide bottom>
                                        <img src={real1} alt='Effectiveness' />
                                        <h3>Effectiveness</h3>
                                        <p>Optimize the efforts of your real estate agency team, wherever they are.</p>
                                    </Slide>
                                </div>
                                <div className='leads__section'>
                                    <Slide bottom>
                                        <img src={real2} alt='Intuitive system' />
                                        <h3>Intuitive system</h3>
                                        <p>The new application of our real estate CRM has been improved to offer maximum ease of use.</p>
                                    </Slide>
                                </div>
                                <div className='leads__section'>
                                    <Slide bottom>
                                        <img src={real3} alt='CRM Akountant is 100% secure' />
                                        <h3>CRM Akountant is 100% secure</h3>
                                        <p>Your data is 100% secure with our multiple security layers available in our real estate program.</p>
                                    </Slide>
                                </div>
                                <div className='leads__section'>
                                    <Slide bottom>
                                        <img src={real4} alt='Effective support' />
                                        <h3>Effective support</h3>
                                        <p>We solve any incident that occurs to you immediately and with the utmost professionalism.</p>
                                    </Slide>
                                </div>
                                <div className='leads__section'>
                                    <Slide bottom>
                                        <img src={real5} alt='Pocket friendly ' />
                                        <h3>Pocket friendly </h3>
                                        <p>The price of our CRM is affordable, considering that no other real estate software has so many features.</p>
                                    </Slide>
                                </div>
                                <div className='leads__section'>
                                    <Slide bottom>
                                        <img src={real6} alt='Save on commercials' />
                                        <h3>Save on commercials</h3>
                                        <p>Working with our CRM Akountant is like having five additional commercials on your real estate agency team.</p>
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                    <FAQs />
                </div>
            </div>
        </>
    )
}

export default Home;