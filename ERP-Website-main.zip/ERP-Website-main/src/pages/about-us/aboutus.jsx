import React from 'react';
import about from '../../assets/images/about.jpg'
import './aboutus.scss';
import { Helmet } from 'react-helmet-async';

const AboutUs = () => {
    return (
        <>
            <Helmet>
                <title>AKOUNTANT | About Us</title>
                <meta name="description" content="AKOUNTANT | About Us" />
                <meta name="keyWords" content="AKOUNTANT | About Us" />
            </Helmet>
            <div className='about'>
                <div className='about__container'>
                    <div className='about__banner' style={{
                        backgroundImage: `url(${about})`,
                        backgroundSize: 'cover', backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'center top'
                    }}>
                        <h2>About us</h2>
                    </div>
                    <div className='about__section'>
                        <div className='about__section__content'>
                            <h4>
                                Yozoi is changing the way domiciliary care and support services are delivered. We are embedding the latest big data and artificial intelligence technologies in a mobile application platform to empower people in communities to deliver on-demand domiciliary services to their senior citizens.
                            </h4>
                            <h4>
                                We are solving social problems emanating from changing demographics such as aging populations. The increase in the percentage of 60+ years old citizens is placing enormous pressures on health and care services. Senior citizens are suffering from support & care systems stressed by costs, quality & labour shortage.
                            </h4>
                            <h4>Yozoi vision is to ‘EMPOWER PEOPLE IN COMMUNITIES TO FULFIL THE DOMICILIARY SERVICE NEEDS OF THEIR SOCIETIES’. Our flexible earnings model with a high-level of training, live support and excellent pay, strives for the well-being of the service providers as much as for the quality of service delivered to customers. Our mission is ‘TO BE THE BEST CROWD SUPPLY-DEMAND MOBILE APPLICATIONS TECHNOLOGY PLATFORM FOR DOMICILIARY SERVICES’, serving both the service providers and customers with a great diligence.</h4>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AboutUs;