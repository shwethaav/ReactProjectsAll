import React, { useState } from 'react';
import './ContactUs.scss';
import bgImage from '../../assets/images/banner/contactus.jpg';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Slide from 'react-reveal/Slide';
import { ContactUsEnquire } from '../utils/apicalls';
import { regex } from '../utils/regex';
import Confirm from '../components/confirmModal/confirm';
import Loader from '../components/loader';

const ContactUs = () => {
    const [firstName, setFirstName] = useState();
    const [lastName, setLastName] = useState();
    const [workEmail, setWorkEmail] = useState();
    const [phoneNumber, setPhoneNumber] = useState();
    const [requirements, setRequirements] = useState();
    const [isShowLoader, setIsShowLoader] = useState(false);
    const [alertText, setAlertText] = useState();
    const [showConfirmModal, setShowConfirmModal] = useState(false);
    const [showConfirmModal1, setShowConfirmModal1] = useState(false);


    const validateEmail = (Email) => {
        const emailRegex = regex.emailRegex;
        return emailRegex.test(Email);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const payload = {
            firstName: firstName,
            lastName: lastName,
            phoneNumer: phoneNumber,
            workEmail: workEmail,
            requirements: requirements,
        }

        console.log(payload)
        if (payload) {
            if (workEmail && firstName && lastName && phoneNumber) {
                if (validateEmail(workEmail)) {
                    ContactUsEnquire((res) => {
                        const { message, statusCode } = res;
                        if (statusCode === 200) {
                            setIsShowLoader(false);
                            setShowConfirmModal(true);
                            setShowConfirmModal1(true);
                            setAlertText(message);
                            // window.location.reload();
                        } else {
                            setShowConfirmModal(false);
                            setShowConfirmModal1(true);
                            setIsShowLoader(false);
                            setAlertText(message);
                        }
                    }, payload)
                } else {
                    setAlertText('Enter Valid Email');
                    setShowConfirmModal(false);
                    setShowConfirmModal1(true);
                    setIsShowLoader(false);
                }
            } else {
                setAlertText('Fill All The Required Fields');
                setShowConfirmModal(false);
                setShowConfirmModal1(true);
                setIsShowLoader(false);
            }

        }
    }

    const handleConfirm = () => {
        window.location.reload();
        setShowConfirmModal(true);
    }

    return (
        <div className='contact'>
            <div className='contact__container'>
                <div className='contact__section'>
                    {/* <div className='contact__section__bg' style={{
                        backgroundImage: `url(${bgImage})`,
                        backgroundSize: 'cover', backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'center top'
                    }}> */}
                    <div className='contact__section__bg'>
                        <div className='contact__section__bg__image'>
                            <img src={bgImage} alt='contact-banner' />
                            <h1>Contact Us</h1>
                        </div>
                        <div className='contact__section-main'>
                            <div className='contact__sections'>
                                <div className='contact__left'>
                                    <div className='contact__left__form'>
                                        <Slide bottom>
                                            <div className='contact__left__form__heading'>
                                                {/* <h2>Contact Us</h2> */}
                                                <h2>Talk with our team</h2>
                                            </div>
                                            <form>
                                                <div className='contact__left__form__inputs flex'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="First Name *"
                                                        placeholder="First Name *"
                                                        multiline
                                                        onChange={(event) => setFirstName(event.target.value)}
                                                    />
                                                </div>
                                                <div className='contact__left__form__inputs flex'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="Last Name *"
                                                        placeholder="Last Name *"
                                                        multiline
                                                        onChange={(event) => setLastName(event.target.value)}
                                                    />
                                                </div>
                                                <div className='contact__left__form__inputs'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="Work Email *"
                                                        placeholder="Work Email *"
                                                        multiline
                                                        onChange={(event) => setWorkEmail(event.target.value)}
                                                    />
                                                </div>
                                                <div className='contact__left__form__inputs'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="Phone No *"
                                                        placeholder="Phone No *"
                                                        multiline
                                                        onChange={(event) => setPhoneNumber(event.target.value)}
                                                        onInput={(e) => {
                                                            e.target.value = Math.max(0, parseInt(e.target.value)).toString().slice(0, 10)
                                                        }}
                                                    />
                                                </div>
                                                <div className='contact__left__form__inputs'>
                                                    <TextField
                                                        id="outlined-textarea"
                                                        label="What would you like to discuss?"
                                                        placeholder="What would you like to discuss?"
                                                        multiline
                                                        rows={3}
                                                        onChange={(event) => setRequirements(event.target.value)}
                                                    />
                                                </div>
                                                <div className='contact__left__form__button'>
                                                    <button onClick={(e) => handleSubmit(e)}>Submit</button>
                                                </div>
                                            </form>
                                        </Slide>
                                    </div>
                                </div>
                                <div className='contact__right'>
                                    <div className='contact__right__section'>
                                        <Slide bottom>
                                            <h2>Take your business to the next level, contact Akountant now </h2>
                                        </Slide>
                                        <Slide bottom>
                                            <h3>Looking for more information about Akountant solutions or want to discuss more about solutions related requirements, connect with us now.</h3>
                                        </Slide>
                                        {/* <h4>Let us help in taking your business to the next level.</h4> */}
                                        <div className='contact__right__section__points'>
                                            <Slide bottom>
                                                <h2>All you have to do is</h2>
                                            </Slide>
                                            <div className='contact__right__section__point'>
                                                <Slide bottom>
                                                    <i className='fa fa-check' />
                                                    <p>Fill the form</p>
                                                </Slide>
                                            </div>
                                            <div className='contact__right__section__point'>
                                                <Slide bottom>
                                                    <i className='fa fa-check' />
                                                    <p>Wait for our team to connect with you</p>
                                                </Slide>
                                            </div>
                                            <div className='contact__right__section__point'>
                                                <Slide bottom>
                                                    <i className='fa fa-check' />
                                                    <p>Explain your requirements</p>
                                                </Slide>
                                            </div>
                                            <div className='contact__right__section__point'>
                                                <Slide bottom>
                                                    <i className='fa fa-check' />
                                                    <p>Select the solution according to your requirements</p>
                                                </Slide>
                                            </div>
                                            {/* <div className='contact__right__section__point'>
                                                <i className='fa fa-check' />
                                                <p>Easy integration of automatic mailing & SMS alert.</p>
                                            </div> */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {showConfirmModal && (
                <Confirm buttonText={'OK'} isCancelRequired={false} confirmTitle={alertText}
                    onConfirm={() => { handleConfirm() }}
                    onCancel={() => { setShowConfirmModal(false) }} />
            )}
            {showConfirmModal1 && (
                <Confirm buttonText={'OK'} isCancelRequired={false} confirmTitle={alertText}
                    onConfirm={() => { setShowConfirmModal1(false) }}
                    onCancel={() => { setShowConfirmModal1(false) }} />
            )}
            {isShowLoader ? <Loader /> : null}
        </div>
    )
}

export default ContactUs;