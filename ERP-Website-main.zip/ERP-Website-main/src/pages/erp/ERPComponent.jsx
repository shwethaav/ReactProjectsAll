import React from 'react';
import './ERPStyles.scss';
import bgbanner from '../../assets/images/subpages/banner-common.jpg';
import icon from '../../assets/images/subpages/icon.png';
import ERPFeatures from '../../assets/images/subpages/erp-banner.svg';
import ERPbanner from '../../assets/images/subpages/erp-features.svg';
import tab1 from '../../assets/images/subpages/erp/Accounting and finance.jpg';
import tab2 from '../../assets/images/subpages/erp/inventory.jpg';
import tab3 from '../../assets/images/subpages/erp/human resource.jpg';
import tab4 from '../../assets/images/subpages/erp/manufacturing.jpg';
import tab5 from '../../assets/images/subpages/erp/warehouse.jpg';
import Slide from 'react-reveal/Slide';
import { Tab, TabPanel, Tabs, TabList } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';

const ERPComponent = () => {
    return (
        <div className='erp'>
            <div className='erp__container'>
                <div className='erp__banner'
                    style={{
                        backgroundImage: `url(${bgbanner})`,
                        backgroundSize: 'cover', backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'center top'
                    }}>
                    <div className='erp__banner__container'>
                        <div className='erp__banner__sections'>
                            <div className='erp__banner__left'>
                                <div className='erp__banner__left__content'>
                                    <Slide left>
                                        <h2>Your Employees Deserve Akountant</h2>
                                        <div className='erp__banner__left__content__line'></div>
                                        <p>Akountant will make your management super easy. With this software, handle your accounting and finances, manage your inventory, monitor multiple warehouses, automate order fulfillment, streamline procurement, and manage sales and marketing. You can avail all the benefits integrated into one platform.</p>
                                    </Slide>
                                </div>
                            </div>
                            <div className='erp__banner__right'>
                                <div className='erp__banner__right__image'>
                                    <Slide right>
                                        <img src={ERPbanner} alt='ERP_Banner' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='erp__features'>
                    <div className='erp__features__container'>
                        <div className='erp__features__sections'>
                            <div className='erp__features__left'>
                                <div className='erp__features__left__content'>
                                    <Slide bottom>
                                        <h2>What Additional Features Does Akountant ERP Offer?</h2>
                                    </Slide>
                                    <div className='erp__features__left__content__line'></div>
                                    <div className='erp__features__left__content__points'>
                                        <div className='erp__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Manage all aspects of your business with Akountant ERP, from financial management to inventory control and manufacturing operations.</p>
                                            </Slide>
                                        </div>
                                        <div className='erp__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Akountant ERP's custom built tools will enable you to gain real-time insights and increase business control, increase data accuracy, reduce costs, fulfill orders faster, and improve customer service.</p>
                                            </Slide>
                                        </div>
                                        <div className='erp__features__left__content__point'>
                                            <Slide bottom>
                                                <img src={icon} alt='icon' />
                                                <p>Get ultimate control over your business process and maximize your efficiency and output by using Akountant ERP.</p>
                                            </Slide>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className='erp__features__right'>
                                <div className='erp__features__right__image'>
                                    <Slide left>
                                        <img src={ERPFeatures} alt='ERP_Features' />
                                    </Slide>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='erp__real'>
                    <div className='erp__real__container'>
                        <div className='erp__real__sections'>
                            <div className='erp__real__heading'>
                                <h2>Real Time Business Operations</h2>
                                <div className='erp__real__heading__line'></div>
                            </div>
                            <div className='erp__real__tabs'>
                                <Tabs>
                                    <TabList>
                                        <Tab>
                                            <div className='erp__real__tabs__tab'>
                                                <div className='erp__real__tabs__tab__section'>
                                                    <h4>Accounting and Finance</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                        <Tab>
                                            <div className='erp__real__tabs__tab'>
                                                <div className='erp__real__tabs__tab__section'>
                                                    <h4>Inventory Management</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                        <Tab>
                                            <div className='erp__real__tabs__tab'>
                                                <div className='erp__real__tabs__tab__section'>
                                                    <h4>Human Resourses</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                        <Tab>
                                            <div className='erp__real__tabs__tab'>
                                                <div className='erp__real__tabs__tab__section'>
                                                    <h4>Manufacturing Operations</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                        <Tab>
                                            <div className='erp__real__tabs__tab'>
                                                <div className='erp__real__tabs__tab__section'>
                                                    <h4>Warehouse Management</h4>
                                                </div>
                                            </div>
                                        </Tab>
                                    </TabList>
                                    <TabPanel>
                                        <div className='erp__real__tabs__tabpanel'>
                                            <div className='erp__real__tabs__tabpanel__section'>
                                                <div className='erp__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab1} alt='ERP_Features' />
                                                    </Slide>
                                                </div>
                                                <div className='erp__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>Accounting and Finance</h3>
                                                        <p>Manage financial processes like budgeting and forecasting, bank reconciliation and multi entity consolidation. Gain visibility into financial performance, segment user roles, automatically generate financial reports, track payments, and forecast future financials.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                    <TabPanel>
                                        <div className='erp__real__tabs__tabpanel'>
                                            <div className='erp__real__tabs__tabpanel__section'>
                                                <div className='erp__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab2} alt='ERP_Features' />
                                                    </Slide>
                                                </div>
                                                <div className='erp__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>Inventory Management</h3>
                                                        <p>Track inventory levels and movements in real-time. Generate stock-level alerts when reaching critical low thresholds. Automate ordering and restocking processes to maintain optimal inventory levels.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                    <TabPanel>
                                        <div className='erp__real__tabs__tabpanel'>
                                            <div className='erp__real__tabs__tabpanel__section'>
                                                <div className='erp__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab3} alt='ERP_Features' />
                                                    </Slide>
                                                </div>
                                                <div className='erp__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>Human Resourses</h3>
                                                        <p>Track employee records and performance, set up payroll and benefit plans, and automate attendance tracking. Streamline HR processes and ensure compliance with local and national regulations. Reduce paperwork and minimize manual data entry for greater efficiency.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                    <TabPanel>
                                        <div className='erp__real__tabs__tabpanel'>
                                            <div className='erp__real__tabs__tabpanel__section'>
                                                <div className='erp__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab4} alt='ERP_Features' />
                                                    </Slide>
                                                </div>
                                                <div className='erp__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>Manufacturing Operations</h3>
                                                        <p>Calculate production costs, track inventory levels, and plan for purchasing and production needs. Automate the creation of purchase orders and production plans, streamlining your operations for maximum efficiency.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                    <TabPanel>
                                        <div className='erp__real__tabs__tabpanel'>
                                            <div className='erp__real__tabs__tabpanel__section'>
                                                <div className='erp__real__tabs__tabpanel__left'>
                                                    <Slide left>
                                                        <img src={tab5} alt='ERP_Features' />
                                                    </Slide>
                                                </div>
                                                <div className='erp__real__tabs__tabpanel__right'>
                                                    <Slide right>
                                                        <h3>Warehouse Management</h3>
                                                        <p>Automate receiving, order picking, and shipping. Manage multiple warehouses. Pick, Pack, and Ship from Warehouses. Utilize advanced analytics to better understand warehouse performance.</p>
                                                    </Slide>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                </Tabs>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ERPComponent;