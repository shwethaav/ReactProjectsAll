// import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './pages/header/header';
import Home from './pages/home/home';
import Footer from './pages/footer/footer';
import ERPComponent from './pages/erp/ERPComponent';
import POSComponent from './pages/pos/POSComponent';
import CRMComponent from './pages/crm/CRMComponent';
import PayrollComponent from './pages/payroll/PAYROLLComponent';
import Pricing from './pages/pricing/Pricing';
import Schedule from './pages/schedule/Schedule';
import ContactUs from './pages/contact-us/ContactUs';

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path='/' element={<Home title='AKOUNTANT | Home' />} />
        <Route path='/ERP' element={<ERPComponent title='AKOUNTANT | ERP' />} />
        <Route path='/POS' element={<POSComponent title='AKOUNTANT | POS' />} />
        <Route path='/PAYROLL' element={<PayrollComponent title='AKOUNTANT | PAYROLL' />} />
        <Route path='/CRM' element={<CRMComponent title='AKOUNTANT | CRM' />} />
        {/* <Route path='/REAL-ESTATE-CRM' element={<ERPComponent title='AKOUNTANT | REAL ESTATE CRM' />} /> */}
        <Route path='/pricing' element={<Pricing title='AKOUNTANT | Pricing' />} />
        <Route path='/schedule-a-demo' element={<Schedule title='AKOUNTANT | SCHEDULE A DEMO' />} />
        <Route path='/contact-us' element={<ContactUs title='AKOUNTANT | CONTACT US' />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
