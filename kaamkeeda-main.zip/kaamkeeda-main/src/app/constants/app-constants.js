export const APP_CONSTANTS = {

};

export const TOAST_TYPE_CONSTANTS = {
  SUCCESS: 'success',
  ERROR: 'error'
};
