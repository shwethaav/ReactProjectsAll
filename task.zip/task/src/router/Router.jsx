import React from "react";
import { BrowserRouter as Router, Routes, Route} from "react-router-dom";
import Home from "..//Component/Home";
import Employess from "../Component/Employee";
import Main from "..//Component/main";
import Add from "..//Component/Add";
import Edit from "..//Component/Edit";


const RouterComponent = () => {
  return (
    <Router>
    
            <Routes>
            <Route path="/" element = {<Home/>} />
            {/* <Route path="/employee" element = {<Employess/>} /> */}
            <Route path="/main" element = {<Main/>} />
            <Route path="/create" element = {<Add/>} />
            <Route path="/edit" element = {<Edit/>} />  
            </Routes>
    </Router>
  );
};

export default RouterComponent;
