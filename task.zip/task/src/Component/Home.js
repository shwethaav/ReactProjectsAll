import React, { useEffect, useState } from 'react';
import { useNavigate, Link, json } from 'react-router-dom';
// import Employees from './Employee';
import { Table } from 'react-bootstrap';

const Home = () => {
    let history = useNavigate();
    const [employees, setEmployees] = useState();

    useEffect(() => {
        const data = localStorage.getItem("employees");
        const parsedData = JSON.parse(data);
        setEmployees(parsedData);
    }, []);
    console.log("employees", employees)
    const handleEdit = (id, name, role, position, experience, userName) => {
        const employeeData = {
            EmployeeID: id,
            EmployeeName: name,
            EmployeeRole: role,
            EmployeePosition: position,
            EmployeeExperience: experience,
            EmployeeUsername: userName,
        };
        localStorage.setItem("editEmployee", JSON.stringify(employeeData));
        history("/edit");
    }
    const handleDelete = (id) => {
        const updatedEmployees = employees.filter(employee => employee.EmployeeID !== id);
        localStorage.setItem("employees", JSON.stringify(updatedEmployees));
        setEmployees(updatedEmployees);
        history('/');
    }
    
    return (
        <div>
            <div style={{ margin: "10rem" }}>
                <center>
            <h5 style={{margin: "2vw"}}>Employee Table</h5></center>
                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>EmployeeID</th>
                            <th>EmployeeName</th>
                            <th>EmployeeRole</th>
                            <th>EmployeePosition</th>
                            <th>EmployeeExperience</th>
                            <th>EmployeeUsername</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            employees
                                ?
                                employees?.map((item , index) => {
                                    return (
                                        <tr key={index}>
                                            <td>
                                                {item.EmployeeID}
                                            </td>
                                            <td>
                                                {item.EmployeeName}
                                            </td>
                                            <td>
                                                {item.EmployeeRole}
                                            </td>
                                            <td>
                                                {item.EmployeePosition}
                                            </td>
                                            <td>
                                                {item.EmployeeExperience}
                                            </td>
                                            <td>
                                                {item.EmployeeUsername}
                                            </td>
                                            <td>
                                                <i className="fa fa-pencil" onClick={() => handleEdit(item.EmployeeID, item.EmployeeName, item.EmployeeRole, item.EmployeePosition, item.EmployeeExperience, item.EmployeeUsername)} />
                                            </td>
                                            <td>
                                            <i className="fa fa-trash" onClick={() => handleDelete(item.EmployeeID)}>
                                                </i>
                                            </td>
                                        </tr>
                                    )
                                }) :
                               "No data availbale"
                        }
                    </tbody>
                </Table>
                <br></br>
                <Link to="/create">
                    <button className='  gap-2  ' style={{ size: "large", backgroundColor: "green" }}>Create</button>
                </Link>
            </div>
        </div>
    );
};

export default Home;
