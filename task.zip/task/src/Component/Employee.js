const Employess=[
    {
        EmployeeID: 1,
          EmployeeName: "shwetha",
       EmployeeRole: "React Developer",
      EmployeePosition: "intern",
     EmployeeExperience:0,
        EmployeeUsername: "shwethadarshu",
    },
    {
        EmployeeID: 2,
          EmployeeName: "santhosh kumar",
       EmployeeRole: "React Developer",
      EmployeePosition: "senior React Developer",
     EmployeeExperience: 2.5 ,
        EmployeeUsername: "santhoshkumar",
    },
    {
        EmployeeID: 3,
          EmployeeName: "Shwetha Bk",
       EmployeeRole: "Angular Developer",
      EmployeePosition: "Senior Angular Developer",
     EmployeeExperience: 1.5,
        EmployeeUsername: "shwethagowda",
    },
    {
        EmployeeID: 4,
          EmployeeName: "Deepika",
       EmployeeRole: "Angular Developer",
      EmployeePosition: "intern",
     EmployeeExperience:0 ,
        EmployeeUsername: "deepikapujari",
    },
    {
        EmployeeID: 5,
          EmployeeName: "sharath",
       EmployeeRole: "Ux/Ui Developer",
      EmployeePosition: "Junior Ux/Ui developer",
     EmployeeExperience:2,
        EmployeeUsername: "sharathgowda",
    },
]
export default Employess;