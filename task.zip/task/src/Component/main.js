// import React, { useState, useEffect } from 'react';

// const EmployeeTable = () => {
//     const [employees, setEmployees] = useState([]);

//     useEffect(() => {
//         const storedEmployees = JSON.parse(localStorage.getItem('employees')) || [];
//         setEmployees(storedEmployees);
//     }, []);

//     const saveToLocalStorage = (data) => {
//         localStorage.setItem('employees', JSON.stringify(data));
//     };

//     const addEmployee = (employee) => {
//         const newEmployees = [...employees, employee];
//         setEmployees(newEmployees);
//         saveToLocalStorage(newEmployees);
//     };

//     const deleteEmployee = (employeeId) => {
//         const updatedEmployees = employees.filter(emp => emp.EmployeeID !== employeeId);
//         setEmployees(updatedEmployees);
//         saveToLocalStorage(updatedEmployees);
//     };

//     const editEmployee = (employeeId, newData) => {
//         const updatedEmployees = employees.map(emp => {
//             if (emp.EmployeeID === employeeId) {
//                 return { ...emp, ...newData};
//             }
//             return emp;
//         });
//         setEmployees(updatedEmployees);
//         saveToLocalStorage(updatedEmployees);
//     };

//     const validateEmployee = (employee) => {
       
//         return true; 
//     };

    
//     return (
//         <div>
//             <h2>Employee Table</h2>
//             <table>
//                 <thead>
//                     <tr>
//                         <th>EmployeeID</th>
//                         <th>EmployeeName</th>
//                         <th>EmployeeRole</th>
//                         <th>EmployeePosition</th>
//                         <th>EmployeeExperience</th>
//                         <th>EmployeeUsername</th>
//                         <th>Action</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                     {employees.map(employee => (
//                         <tr key={employee.EmployeeID}>
//                             <td>{employee.EmployeeID}</td>
//                             <td>{employee.EmployeeName}</td>
//                             <td>{employee.EmployeeRole}</td>
//                             <td>{employee.EmployeePosition}</td>
//                             <td>{employee.EmployeeExperience}</td>
//                             <td>{employee.EmployeeUsername}</td>
//                             <td>
                           
//                                 <button onClick={() => editEmployee(employee.EmployeeID, newData)}>Edit</button>

//                                 <button onClick={() => deleteEmployee(employee.EmployeeID)}>Delete</button>
//                             </td>
//                         </tr>
//                     ))}
//                 </tbody>
//             </table>
//         </div>
//     );
// };

// export default EmployeeTable;
