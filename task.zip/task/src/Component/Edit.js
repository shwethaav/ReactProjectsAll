import React, { useEffect, useState } from 'react';
import { Button, Form } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';

const Edit = () => {
    const [id, setId] = useState("");
    const [name, setName] = useState("");
    const [role, setRole] = useState("");
    const [position, setPosition] = useState("");
    const [experience, setExperience] = useState("");
    const [userName, setUserName] = useState("");
    const [nameError, setNameError] = useState("");
    const [roleError, setRoleError] = useState("");
    const [positionError, setPositionError] = useState("");
    const [experienceError, setExperienceError] = useState("");
    const [usernameError, setUsernameError] = useState("");

    const history = useNavigate();

    useEffect(() => {
        const employeeData = JSON.parse(localStorage.getItem('editEmployee'));
        if (employeeData) {
            setId(employeeData.EmployeeID);
            setName(employeeData.EmployeeName);
            setRole(employeeData.EmployeeRole);
            setPosition(employeeData.EmployeePosition);
            setExperience(employeeData.EmployeeExperience);
            setUserName(employeeData.EmployeeUsername);
        }
    }, []);
    const handleUpdate = (e) => {
        e.preventDefault();
        if (!name || !role || !position || !experience || !userName) {
            setNameError(name ? "" : "Name is required");
            setRoleError(role ? "" : "Role is required");
            setPositionError(position ? "" : "Position is required");
            setExperienceError(experience ? "" : "Experience is required");
            setUsernameError(userName ? "" : "Username is required");
            return;
        }

        if (!userName.trim()) {
            setUsernameError("Username is required");
            return;
        }

        const updatedEmployee = {
            EmployeeID: id,
            EmployeeName: name,
            EmployeeRole: role,
            EmployeePosition: position,
            EmployeeExperience: experience,
            EmployeeUsername: userName,
        };

        const employeesData = JSON.parse(localStorage.getItem("employees"));
        const index = employeesData.findIndex(employee => employee.EmployeeID === id);
        employeesData[index] = updatedEmployee;
        localStorage.setItem("employees", JSON.stringify(employeesData));
        localStorage.removeItem("editEmployee");
        history("/");
    };


    return (
        <div>
            <Form style={{ margin: "15rem" }} onSubmit={handleUpdate}>
                <Form.Control
                    type='text'
                    placeholder='Enter Employee Id'
                    value={id}
                    onChange={(e) => setId(e.target.value)}
                    disabled
                />
                <Form.Control
                    type='text'
                    placeholder='Enter Employee name'
                    value={name}
                    onChange={(e) => {
                        setName(e.target.value);
                        setNameError("");
                    }}
                    onKeyDown={(e) => {
                        if (!/^[a-zA-Z\s]*$/.test(e.key)) {
                            e.preventDefault();
                        }
                    }}
                    isInvalid={nameError !== ""}
                />
                <Form.Control
                    type='text'
                    placeholder='Enter employee role'
                    value={role}
                    onChange={(e) => {
                        setRole(e.target.value);
                        setRoleError("");
                    }}
                    onKeyDown={(e) => {
                        if (!/^[a-zA-Z\s]*$/.test(e.key)) {
                            e.preventDefault();
                        }
                    }}
                    isInvalid={roleError !== ""}
                />
                <Form.Control
                    type='text'
                    placeholder='Enter employee position'
                    value={position}
                    onChange={(e) => {
                        setPosition(e.target.value);
                        setPositionError("");
                    }}
                    onKeyDown={(e) => {
                        if (!/^[a-zA-Z\s]*$/.test(e.key)) {
                            e.preventDefault();
                        }
                    }}
                    isInvalid={positionError !== ""}
                />
                <Form.Control
                    type='text'
                    placeholder='Enter employee experience'
                    value={experience}
                    onChange={(e) => {
                        const inputValue = e.target.value;
                        if (/^\d*$/.test(inputValue)) {
                            setExperience(inputValue);
                            setExperienceError("");
                        } else {
                            setExperienceError("Employee experience must contain only numbers.");
                        }
                    }}
                    onKeyDown={(e) => {
                        if (!/^\d+$/.test(e.key) && !['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) {
                            e.preventDefault();
                        }
                    }}
                    isInvalid={experienceError !== ""}
                />
                <Form.Control
                    type='text'
                    placeholder='Enter employee username'
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    isInvalid={!!usernameError}
                />
                <Form.Control.Feedback type="invalid">
                    {usernameError}
                </Form.Control.Feedback>

                <Button type='submit' style={{ color: "white", backgroundColor: "blue" }}>Update</Button>
            </Form>
        </div>
    );
};

export default Edit;
