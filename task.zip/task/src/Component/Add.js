import React, { useState } from 'react';
import { Button, Form, Alert } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link, useNavigate } from 'react-router-dom';

function Add() {
    const [id, setId] = useState("");
    const [idError, setIdError] = useState("");
    const [name, setName] = useState("");
    const [nameError, setNameError] = useState("");
    const [role, setRole] = useState("");
    const [roleError, setRoleError] = useState("");
    const [position, setPosition] = useState("");
    const [positionError, setPositionError] = useState("");
    const [experience, setExperience] = useState("");
    const [experienceError, setExperienceError] = useState("");
    const [userName, setUserName] = useState("");
    const [userNameError, setUserNameError] = useState("");
    const [showEmptyFieldsError, setShowEmptyFieldsError] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = (e) => {
    e.preventDefault();
    if (!id || !name || !role || !position || !experience || !userName) {
        setShowEmptyFieldsError(true);
        return;
    }
    const existingEmployees = JSON.parse(localStorage.getItem("employees")) || [];
    const isIdExists = existingEmployees.some(employee => employee.EmployeeID === id);
    if (isIdExists) {
        setIdError("Employee with this ID already exists.");
        return;
    }
    const newEmployee = {
        EmployeeID: id,
        EmployeeName: name,
        EmployeeRole: role,
        EmployeePosition: position,
        EmployeeExperience: experience,
        EmployeeUsername: userName,
    };
    existingEmployees.push(newEmployee);
    localStorage.setItem("employees", JSON.stringify(existingEmployees));
    navigate('/');
};

    return (
        <div>
            <Form style={{ margin: "15rem" }}>
                <Form.Control
                    type='id'
                    placeholder='Enter Employee Id'
                    required
                    value={id}
                    onChange={(e) => {
                        const inputValue = e.target.value;
                        if (inputValue === '' || /^\d+$/.test(inputValue)) {
                            setId(inputValue);
                            setIdError('');
                        }
                    }}
                    isInvalid={idError !== ''}
                />
                <Form.Control
                    type='text'
                    placeholder='Enter Employee name'
                    required
                    onChange={(e) => {
                        setName(e.target.value);
                        setNameError("");
                    }}
                    onKeyDown={(e) => {
                        if (!/^[a-zA-Z\s]*$/.test(e.key)) {
                            e.preventDefault();
                        }
                    }}
                    isInvalid={nameError !== ""}
                />
                <Form.Control
                    type='text'
                    placeholder='Enter employee role'
                    required
                    onChange={(e) => {
                        setRole(e.target.value);
                        setRoleError("");
                    }}
                    onKeyDown={(e) => {
                        if (!/^[a-zA-Z\s]*$/.test(e.key)) {
                            e.preventDefault();
                        }
                    }}
                    isInvalid={roleError !== ""}
                />
                <Form.Control.Feedback type="invalid">{roleError}</Form.Control.Feedback>

                <Form.Control
                    type='text'
                    placeholder='Enter employee position'
                    required
                    onChange={(e) => {
                        setPosition(e.target.value);
                        setPositionError("");
                    }}
                    onKeyDown={(e) => {
                        if (!/^[a-zA-Z\s]*$/.test(e.key)) {
                            e.preventDefault();
                        }
                    }}
                    isInvalid={positionError !== ""}
                />
                <Form.Control.Feedback type="invalid">{positionError}</Form.Control.Feedback>

                <Form.Control
                    type='text'
                    placeholder='Enter employee experience'
                    required
                    onChange={(e) => {
                        const inputValue = e.target.value.replace(/\D/g, ''); // Remove non-digit characters
                        setExperience(inputValue);
                    }}
                    onKeyDown={(e) => {
                        if (!/^\d+$/.test(e.key) && !['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) {
                            e.preventDefault();
                        }
                    }}
                />

                <Form.Control.Feedback type="invalid">{experienceError}</Form.Control.Feedback>
                <Form.Control type='text' placeholder='Enter employee username' required onChange={(e) => {
                    setUserName(e.target.value);
                    setUserNameError("");
                }}
                    isInvalid={userNameError !== ""} />
                <Form.Control.Feedback type="invalid">{userNameError}</Form.Control.Feedback>
                {showEmptyFieldsError && (
                    <Alert variant="danger" >
                        Please fill in all fields.
                    </Alert>
                )}
                <Link to={'/edit'}>
                    <Button onClick={(e) => handleSubmit(e)} type='submit' style={{ color: "white", backgroundColor: "blue" }}>Create</Button>
                </Link>
            </Form>
        </div>
    );
}
export default Add;
