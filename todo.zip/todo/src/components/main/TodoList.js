import React, { useState } from 'react';

const TodoList = ({ todolist, deleteHandler, editHandler }) => {
    const [editingIndex, setEditingIndex] = useState(null);
    const [editedTask, setEditedTask] = useState("");
    const handleEditChange = (e) => {
        setEditedTask(e.target.value);
    };
    const handleEditStart = (index, task) => {
        setEditingIndex(index);
        setEditedTask(task);
    };
    const handleEditSave = (index) => {
        editHandler(index, editedTask);
        setEditingIndex(null);
        setEditedTask("");
    };
    const handleEditCancel = (index) => {
        editHandler(null);
        setEditingIndex(null);
        setEditedTask("");
    }
    return (
        <div>
            {todolist.map((todo, index) => (
                <div key={index}>
                    {editingIndex === index ? (
                        <div>
                            <input
                                type="text"
                                value={editedTask}
                                onChange={handleEditChange}
                            />
                            <button onClick={() => handleEditSave(index)}>Save</button>
                            <button onClick={() => handleEditCancel(index)}>Cancel</button>
                        </div>
                    ) : (
                        <div>
                            <h5>{todo} &nbsp;
                                <button onClick={() => deleteHandler(index)}>Delete</button>
                                <button onClick={() => handleEditStart(index, todo)}>Edit</button>
                            </h5>
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
};


export default TodoList;
