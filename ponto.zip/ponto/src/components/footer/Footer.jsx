import React from 'react';
import './Footer.scss';
import logo from '..//..//Assets/images/logo.png';
const Footer = () => {
  return (
    <div>
      <div className="footer">
        <div className="footer_container">
          <div className="footer_container_sections">
                <div className="footer_container_sections_box1">
                  <img src={logo} alt='logo'/>
                  <h4>Ponto Pet</h4> </div>
                  <div className="footer_container_sections_box2">
                    <h5>Address</h5>
                    <ul>
                      <li>500 Terry Francine Street,</li>
                      <li>San Francisco,CA 94158</li>
                    </ul> </div>
                    <div className="footer_container_sections_box3">
                      <h5>Contact</h5>
                      <ul>
                        <li>info@mysite.com</li>
                        <li>123-456-7890</li>
                      </ul></div>
                      <div className="footer_container_sections_box4">
                        <h5>Socials</h5>
                        <ul>
                          <li>Facebook</li>
                          <li>Twitter</li>
                          <li>Youtube</li>
                        </ul>
                     </div>        
            </div>
          </div>
          <div className="footer_container_txt">
            <p>@2035 by Ponto Pet.Powered and secured by Wix</p>
            </div>
        </div>
      </div>
  
  )
}

export default Footer;
