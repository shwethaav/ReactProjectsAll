import React from 'react';
import './Home.scss';
import image1 from '..//..//Assets/images/image1.jpg';
import image2 from '..//..//Assets/images/image2.jpg';
import image3 from '..//..//Assets/images/image3.jpg';
import image4 from '..//..//Assets/images/image4.jpg';
import test1 from '..//..//Assets/images/test_1.png';
import test2 from '..//..//Assets/images/test_2.png';
import test3 from '..//..//Assets/images/test_3.png';
import img1 from '..//..//Assets/images/01.jpg';
import img2 from '..//..//Assets/images/02.jpg';
import img3 from '..//..//Assets/images/03.jpg';
import img4 from '..//..//Assets/images/04.jpg';
import img5 from '..//..//Assets/images/05.jpg';

const Home = () => {
  return (
    <div>
      <div className="home">
        <div className="home_banner">
          <div className="home_banner_image">
            <div className="home_banner_image_heading">
              <h2>The Best Pet Groommers in town</h2>
                <p>For a pawfect look and fenel</p>
              </div>
            </div>
            </div>
            <div className="home_booking">
                <div className="home_booking_heading">
                <h2>Your Pet deserved to be pampered!</h2>
                </div>
                <div className="home_booking_appointment">
                  <div className="home_booking_appointment_container">
                    <div className="home_booking_appointment_container_left">
                    <i class="fa fa-shower" aria-hidden="true"></i><p>Bath or Shower</p>
                    </div>
                    <div className="home_booking_appointment_container_center">
                    <i class="fa fa-paw" aria-hidden="true"></i><p>Hands_on Pets Assesment</p>
                    </div>
                    <div className="home_booking_appointment_container_right">
                    <i class="fa fa-sun-o" aria-hidden="true"></i><p>Safe Drying</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="home_button">
              <button type="buttons">Book an Appointmnet</button>
              </div>
              <div className="home_images">
                <div className="home_images_container">
                <div className="home_images_container_image1">
                  <img src={image1} alt='image1'/></div>
                 <div className="home_images_container_image2">
                  <img src={image2} alt='image2'/></div>
                  <div className="home_images_container_image3">
                    <img src={image3} alt='image3'/> </div>
                    <div className="home_images_container_image4">
                      <img src={image4} alt='image4'/> </div>
                     </div>
              </div>
            <div className="home_feedback">
              <div className="home_feedback_container">
                <div className="home_feedback_container_heading">
                  <h2>What Our Happy Client Says</h2>
                </div>
                </div>
               </div>
               <div className="home_container">
                <div className="home_container_section">
                 <div className="home_container_section_section1">
                  <img src={test1} alt='test1'/>
                  <p>"I'm a testimonial.Click to edit me and add text that says something nice about you and your service."</p><br>
                  </br>
                  <h5>Dani,Pacific Heights</h5>
                 </div>
                  <div className="home_container_section_section2">
                  <img src={test2} alt='test1'/>
                  <p>"I'm a testimonial.Click to edit me and add text that says something nice about you and your service."</p><br>
                  </br>
                  <h5>Tommy, Stonestown</h5>
                  </div>
                  <div className="home_container_section_section3">
                <img src={test3} alt='test1'/>
                  <p>"I'm a testimonial.Click to edit me and add text that says something nice about you and your service."</p><br>
                  </br>
                  <h5>Jill & Emma, Hayes Valley</h5>
                   </div>
              </div>
            </div>
            <div className="home_customer">
                <div className="home_customer_heading">
                  <h5>See All Our Glamorous Customers</h5>
                </div>
                <div className="home_customer_button">
                <button type="buttons">Follow Us</button>
                </div>
                </div>
                <div className="home_customer_images">
                  <div className="home_customer_images_container">
                   <div className="home_customer_images_container_image1">
                    <img src={img1} alt='imag1'/>
                  </div>
                  <div className="home_customer_images_container_image2">
                    <img src={img2} alt='imag2'/>
                  </div>
                  <div className="home_customer_images_container_image3">
                    <img src={img3} alt='imag3'/>
                  </div>
                  <div className="home_customer_images_container_image4">
                    <img src={img4} alt='imag4'/>
                  </div>
                  <div className="home_customer_images_container_image5">
                    <img src={img5} alt='imag5'/>
                  </div>
                    </div>
                </div>
            </div>
           
              </div>
           
  )
}

export default Home;
