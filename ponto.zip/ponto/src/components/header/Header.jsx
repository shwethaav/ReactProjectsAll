// import React from 'react';
import "./Header.scss";
import logo from '..//../Assets/images/logo.png';
import menu from '..//..//Assets/images/menu.png';
import React, { useState } from 'react';


const Header = () => {
  const [sidenav, setSidenav] = useState(false);
  const handlesidenav = () => {
    setSidenav(!sidenav);
    console.log(!sidenav);
  };
  return (
    
    <div>
      <div className="header">
        <div className="header_container">
          <div className="header_container_left">
            <div className="header_container_left_logo">
            <img src={logo} alt="pet_logo"/>
            </div>
            <div className="header_container_left_text">
              <h4>Ponto Pet</h4>
            </div>
          </div>
          <div className="header_container_right">
            <div className="header_container_right_menus">
              <div className="header_container_right_menus_menu">
                <div className="header_container_right_menus_menu_buttons">
                <ul>
                    <li> <button  className=" btn" type="button" >Home</button></li>
                    <li> <button className='btn1' type="button">Services</button></li>
                    <li> <button  className='btn1' type="button">About</button></li>
                    <li> <button  className='btn1' type="button">Contact</button></li>
                    <li> <button  className='btn1' type="button"><i class="fa fa-user" aria-hidden="true"></i>Login</button></li>
                  </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="header_container_right_rightmob">
              <button onClick={handlesidenav}>
                <img src={menu} alt="menu" />
              </button>
              {sidenav && (
                <div className="main_body_header_right_buttons">
                  <a className="btn" href="#H1">
                    Home
                  </a>
                  <a className="btn" href="#C1">
                    Services
                  </a>
                  <a className="btn" href="#C2">
                    About
                  </a>
                  <a className="btn" href="#C3">
                    Contact
                  </a>
                </div>
              )}
            </div>
          </div> 
        </div> 
       </div>
  )
}
export default Header;
