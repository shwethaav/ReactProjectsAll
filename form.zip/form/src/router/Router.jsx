import React from "react";
import { BrowserRouter as Router, Routes, Route} from "react-router-dom";
import Home from "..//components/home/Home";
// import ParentComponent from "..//components/home/ParentComponent";
const RouterComponent = () => {
  return (
    <Router>
    
            <Routes>
            <Route path="/" element = {<Home/>} /> 
            {/* <Route path="/parentcomponent" element = {<ParentComponent/>} /> */}
            </Routes>
    </Router>
  );
};

export default RouterComponent;
