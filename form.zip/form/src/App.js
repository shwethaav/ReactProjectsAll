import './App.css';
import RouterComponent from './router/Router';

function App() {
  return (
    <div className="App">
      <RouterComponent />
      </div>
    
  );
}

export default App;
