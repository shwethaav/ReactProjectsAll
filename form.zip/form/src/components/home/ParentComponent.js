import React, { useState } from 'react';
import EmployeeForm from './EmployeeForm';

const App = () => {
  const [employees, setEmployees] = useState([]);

  const addEmployee = (newEmployee) => {
    setEmployees([...employees, newEmployee]);
  };

  return (
    <div>
      <h1>Employee Management System</h1>
      <EmployeeForm addEmployee={yourAddEmployeeFunction} editMode={false} />
      {/* other components or code */}
    </div>
  );
};

export default App;
