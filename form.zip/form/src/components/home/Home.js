import React, { useEffect, useState } from 'react';

const EmployeeForm = ({
  addEmployee,
  editMode,
  employeeToEdit,
  updateEmployee,
}) => {
  const [employee, setEmployee] = useState({
    employeeName: "",
    employeePhonenumber: "",
    employeeEmail: "",
    employeePassword: "",
    employeeConfirmPassword: "",
  });

  const [errors, setErrors] = useState({
    employeeName: "",
    employeePhonenumber: "",
    employeeEmail: "",
    employeePassword: "",
    employeeConfirmPassword: "",
  });

  useEffect(() => {
    if (editMode && employeeToEdit) {
      setEmployee(employeeToEdit);
    }
  }, [editMode, employeeToEdit]);

  useEffect(() => {
    const storedEmployeeData = localStorage.getItem('employeeFormData');
    if (storedEmployeeData) {
      setEmployee(JSON.parse(storedEmployeeData));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    let error = "";

    if (value.trim() === "") {
      error = "This field is required";
    }

    switch (name) {
      case "employeeName":
        if (!/^[A-Za-z\s]+$/.test(value)) {
          error = "Employee name should contain only letters and spaces";
        }
        break;

      case "employeePhonenumber":
        if (!/^\d+$/.test(value)) {
          error = "Employee phone number should contain only numbers";
        }
        break;

      case "employeeEmail":
        if (!/\S+@\S+\.\S+/.test(value)) {
          error = "Invalid email address";
        }
        break;

      case "employeePassword":
        if (!/(?=.*[!@#$%^&*])/.test(value)) {
          error = "Password must contain at least one special character";
        }
        break;

      case "employeeConfirmPassword":
        if (value !== employee.employeePassword) {
          error = "Passwords do not match";
        }
        break;

      default:
        break;
    }
    setErrors({ ...errors, [name]: error });
    setEmployee({ ...employee, [name]: value });
    localStorage.setItem('employeeFormData', JSON.stringify({ ...employee, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (Object.values(errors).every((error) => error === "")) {
      if (editMode) {
        updateEmployee(employee);
      } else {
        addEmployee(employee);
      }
      setEmployee({
        employeeName: "",
        employeePhonenumber: "",
        employeeEmail: "",
        employeePassword: "",
        employeeConfirmPassword: "",
      });
      setErrors({
        employeeName: "",
        employeePhonenumber: "",
        employeeEmail: "",
        employeePassword: "",
        employeeConfirmPassword: "",
      });
      localStorage.removeItem('employeeFormData');
    } else {
      console.log("Form contains errors");
    }
  };

  return (
    <>
      <form className='form' onSubmit={handleSubmit}>
        <label>
          Employee Name:
          <input type='text' name="employeeName" value={employee.employeeName} onChange={handleChange} />
          {errors.employeeName && <span className="error">{errors.employeeName}</span>}
        </label>
        <br />
        <label>
          Employee Phonenumber:
          <input type='text' name="employeePhonenumber" value={employee.employeePhonenumber} onChange={handleChange} />
          {errors.employeePhonenumber && <span className="error">{errors.employeePhonenumber}</span>}
        </label>
        <br />
        <label>
          Employee Email Address:
          <input type='text' name='employeeEmail' value={employee.employeeEmail} onChange={handleChange} />
          {errors.employeeEmail && <span className="error">{errors.employeeEmail}</span>}
        </label>
        <br />
        <label>
          Employee Password:
          <input type='password' name='employeePassword' value={employee.employeePassword} onChange={handleChange} />
          {errors.employeePassword && <span className="error">{errors.employeePassword}</span>}
        </label>
        <br />
        <label>
          Employee Confirm Password:
          <input type='password' name='employeeConfirmPassword' value={employee.employeeConfirmPassword} onChange={handleChange} />
          {errors.employeeConfirmPassword && <span className="error">{errors.employeeConfirmPassword}</span>}
        </label>
        <br />
        <button type="submit">{editMode ? "Update" : "Add"} Employee</button>
      </form>
    </>
  );
};

export default EmployeeForm;
