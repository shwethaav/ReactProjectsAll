// import React, { useState, useEffect } from "react";
// import "./Data.scss";

// const EmployeeForm = ({
//   addEmployee,
//   editMode,
//   employeeToEdit,
//   updateEmployee,
// }) => {
//   const [employee, setEmployee] = useState({
//     EmployeeID: "",
//     EmployeeName: "",
//     EmployeeRole: "",
//     EmployeePosition: "",
//     EmployeeExperience: "",
//     EmployeeUsername: "",
//     EmployeeEmail: "",
//     EmployeePassword: "",
//   });

//   const [errors, setErrors] = useState({
//     EmployeeID: "",
//     EmployeeName: "",
//     EmployeeRole: "",
//     EmployeePosition: "",
//     EmployeeExperience: "",
//     EmployeeUsername: "",
//     EmployeeEmail: "",
//     EmployeePassword: "",
//   });

//   const [showPassword, setShowPassword] = useState(false);

//   useEffect(() => {
//     if (editMode && employeeToEdit) {
//       setEmployee(employeeToEdit);
//     }
//   }, [editMode, employeeToEdit]);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     let error = "";

//     if (value.trim() === "") {
//       error = "";
//     }

//     switch (name) {
//       case "EmployeeName":
//         if (!/^[A-Za-z\s]*$/.test(value)) {
//           return
//         }
//         break;

//       case "EmployeeRole":
//       case "EmployeePosition":
//         if (!/^[A-Za-z\s]*$/.test(value)) {
//           return;
//         }
//         break;
//       case "EmployeeID":
//       case "EmployeeExperience":
//         if (value !== "" && !/^\d+$/.test(value)) {
//         }
       
//         break;
//       case "EmployeeEmail":
//         if (!/\S+@\S+\.\S+/.test(value)) {
//         }
//         break;
//       case "EmployeePassword":
//         if (!/(?=.*[!@#$%^&*])/.test(value)) {
//           error = "Password must contain at least one special character";
//         }
//         break;
//       default:
//         break;
//     }
//     setErrors({ ...errors, [name]: error });
//     setEmployee({ ...employee, [name]: value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (Object.values(errors).every((error) => error === "")) {
//       if (editMode) {
//         updateEmployee(employee);
//       } else {
//         addEmployee(employee);
//       }
//       setEmployee({
//         EmployeeID: "",
//         EmployeeName: "",
//         EmployeeRole: "",
//         EmployeePosition: "",
//         EmployeeExperience: "",
//         EmployeeUsername: "",
//         EmployeeEmail: "",
//         EmployeePassword: "",
//       });
//       setErrors({
//         EmployeeID: "",
//         EmployeeName: "",
//         EmployeeRole: "",
//         EmployeePosition: "",
//         EmployeeExperience: "",
//         EmployeeUsername: "",
//         EmployeeEmail: "",
//         EmployeePassword: "",
//       });
//     } else {
//       console.log("Form contains errors");
//     }
//   };

//   const togglePasswordVisibility = () => {
//     setShowPassword(!showPassword);
//   };

//   return (
//     <form className="form" onSubmit={handleSubmit}>
//       <label>
//         Employee ID:
//         <input
//           type="number"
//           name="EmployeeID"
//           value={employee.EmployeeID}
//           onChange={handleChange}
//           disabled={employeeToEdit !== null}
//           required
//         />
//         {errors.EmployeeID && (
//           <span className="error">{errors.EmployeeID}</span>
//         )}
//       </label>
//       <br />
//       <label>
//         Employee Name:
//         <input
//           type="text"
//           name="EmployeeName"
//           value={employee.EmployeeName}
//           onChange={handleChange}
//           required
//         />
//         {errors.EmployeeName && (
//           <span className="error">{errors.EmployeeName}</span>
//         )}
//       </label>
//       <br />
//       <label>
//         Employee Role:
//         <input
//           type="text"
//           name="EmployeeRole"
//           value={employee.EmployeeRole}
//           onChange={handleChange}
//           required
//         />
//         {errors.EmployeeRole && (
//           <span className="error">{errors.EmployeeRole}</span>
//         )}
//       </label>
//       <br />
//       <label>
//         Employee Position:
//         <input
//           type="text"
//           name="EmployeePosition"
//           value={employee.EmployeePosition}
//           onChange={handleChange}
//           required
//         />
//         {errors.EmployeePosition && (
//           <span className="error">{errors.EmployeePosition}</span>
//         )}
//       </label>
//       <br />
//       <label>
//         Employee Experience:
//         <input
//           type="number"
//           name="EmployeeExperience"
//           value={employee.EmployeeExperience}
//           onChange={handleChange}
//           required
//         />
//         {errors.EmployeeExperience && (
//           <span className="error">{errors.EmployeeExperience}</span>
//         )}
//       </label>
//       <br />
//       <label>
//         Employee Username:
//         <input
//           type="text"
//           name="EmployeeUsername"
//           value={employee.EmployeeUsername}
//           onChange={handleChange}
//           required
//         />
//         {errors.EmployeeUsername && (
//           <span className="error">{errors.EmployeeUsername}</span>
//         )}
//       </label>
//       <br />
//       <label>
//         Employee Email:
//         <input
//           type="email"
//           name="EmployeeEmail"
//           value={employee.EmployeeEmail}
//           onChange={handleChange}
//           required
//         />
//         {errors.EmployeeEmail && (
//           <span className="error">{errors.EmployeeEmail}</span>
//         )}
//       </label>
//       <br />
//       <label>
//         Employee Password:
//         <input
//           type={showPassword ? "text" : "password"}
//           name="EmployeePassword"
//           value={employee.EmployeePassword}
//           onChange={handleChange}
//           required
//         />
//         <button type="button" onClick={togglePasswordVisibility}>
//           {showPassword ? "Hide" : "Show"} Password
//         </button>
//         {errors.EmployeePassword && (
//           <span className="error">{errors.EmployeePassword}</span>
//         )}
//       </label>
//       <br />
//       <button type="submit">{editMode ? "Update" : "Add"} Employee</button>
//     </form>
//   );
// };

// const App = () => {
//   const [employees, setEmployees] = useState([]);
//   const [editMode, setEditMode] = useState(false);
//   const [employeeToEdit, setEmployeeToEdit] = useState(null);

//   useEffect(() => {
//     const storedEmployees = JSON.parse(localStorage.getItem("employees"));
//     if (storedEmployees) {
//       setEmployees(storedEmployees);
//     }
//   }, []);

//   useEffect(() => {
//     localStorage.setItem("employees", JSON.stringify(employees));
//   }, [employees]);

//   const addEmployee = (employee) => {
//     const newEmployee = { ...employee};
//     setEmployees([...employees, newEmployee]);
//   };

//   const deleteEmployee = (id) => {
//     setEmployees(employees.filter((emp) => emp.EmployeeID !== id));
//   };

//   const editEmployee = (employee) => {
//     setEditMode(true);
//     setEmployeeToEdit(employee);
//   };

//   const updateEmployee = (updatedEmployee) => {
//     const updatedEmployees = employees.map((emp) =>
//       emp.EmployeeID === updatedEmployee.EmployeeID ? updatedEmployee : emp
//     );
//     setEmployees(updatedEmployees);
//     setEditMode(false);
//     setEmployeeToEdit(null);
//   };

//   return (
//     <div>
//       <h1 className="heading">Employee Management</h1>
//       <EmployeeForm
//         addEmployee={addEmployee}
//         editMode={editMode}
//         employeeToEdit={employeeToEdit}
//         updateEmployee={updateEmployee}
//       />
//       <EmployeeTable
//         employees={employees}
//         deleteEmployee={deleteEmployee}
//         editEmployee={editEmployee}
//       />
//     </div>
//   );
// };

// const EmployeeTable = ({ employees, deleteEmployee, editEmployee }) => {
//   return (
//     <table>
//       <thead>
//         <tr>
//           <th>Employee ID</th>
//           <th>Employee Name</th>
//           <th>Employee Role</th>
//           <th>Employee Position</th>
//           <th>Employee Experience</th>
//           <th>Employee Username</th>
//           <th>Employee Email</th>
//           <th>Employee Password</th>
//           <th>Action</th>
//         </tr>
//       </thead>
//       <tbody>
//         {employees.map((employee) => (
//           <tr key={employee.EmployeeID}>
//             <td>{employee.EmployeeID}</td>
//             <td>{employee.EmployeeName}</td>
//             <td>{employee.EmployeeRole}</td>
//             <td>{employee.EmployeePosition}</td>
//             <td>{employee.EmployeeExperience}</td>
//             <td>{employee.EmployeeUsername}</td>
//             <td>{employee.EmployeeEmail}</td>
//             <td>{employee.EmployeePassword}</td>
//             <td>
//               <button className="button" onClick={() => editEmployee(employee)}>
//                 Edit
//               </button>
//               <button
//                 className="button1"
//                 onClick={() => deleteEmployee(employee.EmployeeID)}
//               >
//                 Delete
//               </button>
//             </td>
//           </tr>
//         ))}
//       </tbody>
//     </table>
//   );
// };

// export default App;
