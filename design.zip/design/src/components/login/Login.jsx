import React from "react";
import "./Login.scss";
import profile1 from "..//..//assets/Profile 1.png";
import profile2 from "..//..//assets/Profile 2.png";
import profile3 from "..//..//assets/Profile 3.png";
import profile4 from "..//..//assets/Profile 4.png";
import profile5 from "..//..//assets/Profile 5.png";

const Login = () => {
  return (
    <div>
      <div className="login">
        <div className="login_container">
          <div className="login_container_heading">
            <i class="fa fa-arrow-left"></i>
            <div className="login_container_heading_ask">
            <i class="fa fa-comment"></i>
            <p>Ask</p>
            </div>
            <div className="login_container_heading_search">
            <i class="fa fa-search"></i>
            <p>FAQ</p>
            </div>
          </div>
          <div className="login_container_logos">
            <img src={profile1} alt="" />
            <img src={profile2} alt="" />
            <img src={profile3} alt="" />
            <img src={profile4} alt="" />
            <img src={profile5} alt="" />
          </div>
          <div className="login_container_contents">
            <h2>How can we help?</h2>
            <p>We usually respond in few hours</p>
          </div>
        </div>
      </div>
      <div className="name">
        <div className="name_container">
        <div className="consult_container_right_container_tabs">
              <h5>Name</h5>
              <input
                type="text"
                // placeholder="i.e. john Doe"
                name="name"
                />
              <h5>Phone number</h5>
              <input
                type="text"
                // placeholder="i.e. 123-456-7890"
                name="phone"
              />
              <h5>Email Address</h5>
              <input
                type="text"
                name="email address"
                // placeholder="i.e.john@mail.com"
              />
              <h5>How can we help? </h5>
              <input
                type="text"
                name="service" className="service"
              />
          <button>Send a message</button>
        </div>
      </div>
    </div>
    </div>
  );
};

export default Login;
