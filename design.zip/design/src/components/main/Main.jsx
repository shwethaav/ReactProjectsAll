import React, { useState } from "react";
import "./Main.scss";
import img1 from "..//../assets/Group-61@2x.png";
import img2 from "..//..//assets/Group-62@2x.png";
import click from "../../assets/touch-icons-free-download-png-and-svg.svg";
import img63 from "..//..//assets/Group-63@2x.png";
import mask from "../../assets/Mask-Group-15@2x.png";
import img65 from "..//..//assets/Group-65@2x.png";
import airpods from "..//..//assets/Airpods@2x-e1587482406135.png";
import person from "..//..//assets/person.png";
import mini from "..//../assets/mini.png";
import img69 from "..//../assets/Group-69@2x.png";
import sharing from "..//..//assets/sharing.png";
import air1 from "..//..//assets/airpods-1.png";
import air2 from "..//..//assets/airpods-2.png";
import air3 from "..//..//assets/airpods-3.png";
import air4 from "..//..//assets/airpods-4.png";
import img70 from "..//..//assets/Group-70@2x-e1587508120554.png";
import bottom1 from "..//..//assets/airpods-bottom1.png";
import bottom2 from "..//..//assets/airpods-bottom2.png";
import Header from "..//..//components/header/Header";
import Fade from "react-reveal/Fade";
import Roll from "react-reveal/Roll";
import Slide from "react-reveal/Slide";
import Reveal from "react-reveal/Reveal";
import Bounce from "react-reveal/Bounce";
import Flip from "react-reveal/Flip";
import Login from "../login/Login";
import Zoom from "react-reveal/Zoom";
const Main = () => {
  const [showLogin, setShowLogin] = useState(false);
  const[hideButtons,sethideButtons] = useState(false);
  const handleLogin = () => {
    setShowLogin(!showLogin);
    sethideButtons(!hideButtons)
  };

  return (
    <div>
      <Header />
      <div className="main">
        <div className="main_container">
          <div className="main_container_left">
            <Fade left>
              <h1>AirPods</h1>
              <h2>more magical than Ever.</h2>
              <p>
                Now with more talk time, voice-activated Siri access — and a new
                wireless charging case — AirPods deliver an unparalleled
                wireless headphone experience. Simply take them out and they’re
                ready to use with all your devices. Put them in your ears and
                they connect immediately, immersing you{" "}
              </p>
            </Fade>
            <button>
              <i class="fa fa-play-circle-o"></i>
              Watch the film
            </button>
          </div>
          <div className="main_container_right">
            <div className="main_container_right_container">
              <div className="main_container_right_container_img1">
                <img src={img1} alt="" />
              </div>
              <div className="main_container_right_container_img2">
                <img src={img2} alt="" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="contents">
        <div className="contents_heading">
          <h1>Wireless to the fullest.</h1>
          <p>
            After a simple one-tap setup, AirPods are automatically on and
            always connected.1 Using them is just as easy. They sense when
            they’re in your ears and pause when you take them out. And the
            AirPods experience is just as amazing whether you’re using them with
            your iPhone, Apple Watch, iPad, or Mac.
          </p>
        </div>
      </div>
      <div className="main_container1">
        <div className="main_container1_left">
          <img src={click} alt="" />
          <Fade right>
            <h1>Double tab to call Siri</h1>

            <p>
              When you take your AirPods out of the case, they're on and ready
              to use. When you put them in your ears, your AirPods automatically
              play the audio from your device. If you take an AirPod out, audio
              pauses. Take them both out and audio stops. If you're listening
              with one AirPod and you take it out, the AirPod pauses. If you put
              it back in your ear within 15 seconds, play resumes automatically.
            </p>
          </Fade>
        </div>
        <div className="main_container1_right">
          <div className="main_container1_right_container">
            <div className="img1">
              <img src={img63} alt="" />
            </div>
          </div>
        </div>
      </div>
      <div className="main_container2">
        <div className="main_container2_contents">
          <div className="main_container2_contents_left">
            <h1>Easy setup magical results.</h1>
            <p>
              When you take your AirPods out of the case, they're on and ready
              to use. When you put them in your ears, your AirPods automatically
              play the audio from your device. If you take an AirPod out, audio
              pauses. Take them both out and audio stops. If you're listening
              with one AirPod and you take it out, the AirPod pauses. If you put
              it back in your ear within 15 seconds, play resumes automatically.
            </p>
            <button>
              <i class="fa fa-play-circle-o"></i>Watch the film
            </button>
          </div>
          <div className="main_container2_contents_right">
            <div className="main_container2_contents_right_container">
              <Zoom>
                <div className="main_container2_contents_right_container_img1">
                  <img src={mask} alt="" />
                </div>
                <div className="main_container2_contents_right_container_img2">
                  <img src={img65} alt="" />
                </div>
                <div className="main_container2_contents_right_container_img3">
                  <img src={airpods} alt="" />
                </div>
              </Zoom>
            </div>
          </div>
        </div>
      </div>
      <Zoom>
        <div className="person">
          <div className="person_container">
            <div className="person_container_heading">
              <h1>Pocketable slim design on the go</h1>
              <p>
                Slip them in your pocket and go. Apple air pods feature a newly
                refined design that makes them so compact they fit in
                comfortably with the rest of your belongings. They also come in
                standard color options that blend right in to your daily
                routine.
              </p>
            </div>
            <Zoom>
              <div className="person_container_img">
                <img src={person} alt="" />
              </div>
            </Zoom>
          </div>
        </div>
      </Zoom>
      <div className="main_container3">
        <div className="main_container3_contents">
          <div className="main_container3_contents_left">
            <Slide left>
              <h1>Wireless Charging Case</h1>
              <p>
                When you take your AirPods out of the case, they're on and ready
                to use. When you put them in your ears, your AirPods
                automatically play the audio from your device. If you take an
                AirPod out, audio pauses. Take them both out and audio stops. If
                you're listening with one AirPod and you take it out, the AirPod
                pauses. If you put it back in your ear within 15 seconds, play
                resumes automatically.
              </p>
            </Slide>
            <div className="main_container3_contents_left_img">
              <Zoom>
                <img src={mini} alt="" />
              </Zoom>
              <button>
                <i class="fa fa-play-circle-o"></i>Watch the film
              </button>
            </div>
          </div>
          <div className="main_container3_contents_right">
            <div className="main_container3_contents_right_container">
              <div className="main_container3_contents_right_container_img1">
                <Flip top>
                  <img src={img69} alt="" />
                </Flip>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="audio">
        <div className="audio_container">
          <div className="audio_container_heading">
            <Reveal effect="fadeInUp">
              <h1>Audio Sharing</h1>
              <p>
                With one simple tap, share a song, podcast, or other audio
                stream between two sets of AirPods — each with independent
                volume control.
              </p>
            </Reveal>
          </div>
          <div className="audio_container_imgs">
            <img src={air1} alt="" className="img1" />
            <img src={air2} alt="" className="img2" />
            <img src={sharing} alt="" />
            <img src={air3} alt="" className="img3" />
            <img src={air4} alt="" className="img4" />
          </div>
        </div>
      </div>
      <div className="music">
        <div className="music_container">
          <div className="music_container_left">
            <div className="music_container_left_heading">
              <Bounce left>
                <h1>
                  Music <br></br>Lose yourself in 50 million songs
                </h1>
              </Bounce>
              <Roll top>
                <button>Try it Today</button>
              </Roll>
            </div>
          </div>
          <div className="music_container_right">
            <div className="music_container_right_img">
              <img src={img70} alt="" className="img70" />
              <img src={bottom1} alt="" className="bottom1" />
              <img src={bottom2} alt="" className="bottom2" />
            </div>
          </div>
        </div>
      </div>
      <div className="airpods">
        <div className="airpods_container">
          <div className="airpods_container_heading">
            <Reveal effect="fadeInUp">
              <h1>AirPods</h1>
              <h6>Copyright © 2024 phlox Inc. All rights reserved.</h6>
            </Reveal>
          </div>
        </div>
      </div>
      <div className="buttons">
        <div className={`buttons_container ${hideButtons ? 'hide' : ''}`}>
          <div className="buttons_container_btn1">
            <i class="fa fa-play-circle-o"></i>
            <span>Browse Demos</span>
          </div>
          <div className="buttons_container_btn2">
            <i class="fa fa-play-circle-o"></i>
            <span>Buy Now!</span>
          </div>
          <div className="buttons_container_btn3">
            <i class="fa fa-play-circle-o"></i>
            <span>Export Section</span>
          </div>
        </div>
      </div>
      {showLogin && (
        <div className="logining">
          <Login />
        </div>
      )}

      <div className="chat"  onClick={handleLogin} >
        <div className="chat_container">
          <div className="chat_container_icon">
            <i class="fa fa-comment"></i>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Main;
