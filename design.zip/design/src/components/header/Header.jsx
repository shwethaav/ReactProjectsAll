import React from 'react';
import './header.scss';

const Header = () => {
  return (
    <div>
      <div className="heading">
        <div className="heading_main">
          <div className="heading_main_container">
            <div className="heading_main_container_left">
                <h2>Airpods</h2>
            </div>
            <div className="heading_main_container_right">
                <ul>
                    <li>HIGHLIGHTS</li>
                    <li>COMMANDS</li>
                    <li>PAIRING</li>
                    <li>LIFE STYLE</li>
                    <li>TECHNOLOGY</li>
                    <li>SPECIFICATION</li>
                </ul>
            </div>
        </div>
        </div>
      </div>
    </div>
  )
}

export default Header
