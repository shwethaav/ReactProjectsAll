import React from "react";
import { BrowserRouter as Router, Routes,Route} from "react-router-dom";
import Main from "..//components/main/Main";
import Login from "../components/login/Login";



const RouterComponent = () => {
  return (
    <Router>
      {/* <Header/> */}
            <Routes>
            <Route path="/" element = {<Main/>} />
            <Route path="/login" element = {<Login/>} />
            </Routes>
    </Router>
  );
};

export default RouterComponent;
