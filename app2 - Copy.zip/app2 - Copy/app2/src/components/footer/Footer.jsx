import React from 'react';
import './Footer.scss';
const Footer = () => {
  return (
    <div>
      <div className="footer">
        <div className="footer_container">
          <div className="footer_container_menu">
            <ul>
              <li className='company'>Company</li>
              <li>About Us</li>
              <li>Contact Us</li>
              <li>Careers</li>
              <li>Press</li>
            </ul>
          </div>
          <div className="footer_container_menu">
            <ul>
              <li className='company'>Product</li>
              <li>Features</li>
              <li>Pricing</li>
              <li>News</li>
              <li>Help Desk</li>
              <li>Support</li>
            </ul>
          </div>
          <div className="footer_container_menu">
            <ul>
              <li className='company'>Service</li>
              <li>Digital Marketing</li>
              <li>Content Writting</li>
              <li>SEO for Business</li>
              <li>UI Design</li>
            </ul>
          </div>
          <div className="footer_container_menu">
            <ul>
              <li className='company'>Legal</li>
              <li>Privacy Policy</li>
              <li>Terms Conditions</li>
              <li>Return Policy</li>
            </ul>
          </div>
          <div className="footer_container_contact">
            <ul>
              <li className='contact'>Contact Us</li>
              <li>support@brainwave.io</li>
              <li>+133-394-3439-1435</li>
            </ul>
          </div>
        </div>
      </div>
      <div className="contents">
        <div className="contents_container">
        <p>@2024 Copyright, All Right Reserved, Made by Seju_ui_ux with</p>
        
        <div className="contents_container_icons">
        <i class="fa fa-twitter" style={{color:"lightgray"}}></i>
        <i class="fa fa-facebook" style={{backgroundColor:"blue", color:"white", padding:"0.2vw"}}></i>
        <i class="fa fa-instagram" style={{color:"lightgray"}}></i>
        <i class="fa fa-linkedin" style={{color:"lightgray"}}></i>
        </div>
        </div>
      </div>
    </div>
  )
}

export default Footer;;
