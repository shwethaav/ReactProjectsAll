import React, { useState } from "react";
import "./Header.scss";

const Header = () => {
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const handleMobileMenu = () => {
    setShowMobileMenu(!showMobileMenu);
  };
  return (
    <div>
      <div className="header">
        <div className="header_container">
          <div className="header_container_left">
            <div className="header_container_left_heading">
              <h2>Brainwave.io</h2>
            </div>
            <div className="header_container_left_menus">
              <ul>
                <li>Demos</li>
                <li>Pages</li>
                <li>support</li>
                <li>contact</li>
              </ul>
            </div>
          </div>
          <div className="header_container_right">
            <button>Get started now</button>
          </div>
          <div className="header_container_mobilemenu">
            <div className="header_container_header_container_mobilemenu_icons">
              <i class="fa fa-bars" onClick={handleMobileMenu}></i>
            </div>
            {showMobileMenu && (
              <div className="header_container_header_container_mobilemenu_mobilemenulist">
                <ul>
                  <li>Demos</li>
                  <li>Pages</li>
                  <li>support</li>
                  <li>contact</li>
                  <button>Get started now</button>
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
