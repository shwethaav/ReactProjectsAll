import React, { useState } from "react";
import "./Home.scss";
import Header from "../header/Header";
import img1 from "..//..//assets/Digital.png";
import img2 from "..//..//assets/Content.png";
import img3 from "..//..//assets/Graphic.png";
import img4 from "..//..//assets/SEO.png";
import choose from "..//..//assets/choose.png";
import logo from "..//..//assets/Company Logo.png";
import pic from "..//..//assets/name.png";
import logo1 from "..//..//assets/Google.png";
import pic1 from "..//..//assets/name2.png";
import pic2 from "..//..//assets/name3.png";

const Home = () => {
  const [validationErrors, setValidationErrors] = useState({});

  const initialFormData = {
    name: "",
    emailAddress: "",
    phone: "",
    service: "",
  };
  const [formData, setFormData] = useState(initialFormData);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  const handleSubmit = (event) => {
    console.log("formdata", formData);
    event.preventDefault();
    if (validateForm()) {
      console.log("Form submitted:", formData);
    } else {
      console.log("Form validation failed.");
    }
  };

  const validateForm = () => {
    const errors = {};

    if (
      formData.name === "" ||
      formData.emailAddress === "" ||
      formData.phone === "" ||
      formData.service === ""
    ) {
      errors.name = "Please fill out all fields";
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.emailAddress)) {
      errors.email = "Please enter a valid email address";
    }

    const phoneRegex = /^\d{3}\d{3}\d{4}$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.phone = "Please enter a valid phone number (e.g., 1234567890)";
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  return (
    <>
      <Header />
      <div className="home">
        <div className="home_container">
          <div className="home_container_contents">
            <h4>Get help from the expert consultants.</h4>
            <p>
              With lots of unique blocks, you can easily build a page without
              coding. Build your next consultancy website within few minutes
            </p>
            <div className="home_container_button">
              <button>
                Get started now
                <i class="fa fa-arrow-right"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="count">
        <div className="count_container">
          <div className="count_container_left">
            <h1>1M+</h1>
            <p>Customers visit Albino every months</p>
            <div className="count_container_center">
              <h1>93%</h1>
              <p>Satisfaction rate from our customers.</p>
              <div className="count_container_right">
                <h1>4.9</h1>
                <p>Average customer ratings out of 5.00!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="service">
        <div className="service_container">
          <div className="service_container_heading">
            <h3>Service we offer for you</h3>
            <p>
              With lots of unique blocks , you can easily build a page without
              coding.build your next landing page.
            </p>
          </div>
          <div className="service_container_image">
            <div className="service_container_image_card">
              <div className="service_container_image_card_img">
                <img src={img1} alt="" />
              </div>
              <div className="service_container_image_card_mid">
                <div className="service_container_image_card_mid_left">
                  <p>Digital Marketing</p>
                  <i class="fa fa-arrow-right"></i>
                </div>
              </div>
            </div>
            <div className="service_container_image_card">
              <div className="service_container_image_card_img">
                <img src={img2} alt="" />
              </div>
              <div className="service_container_image_card_mid">
                <div className="service_container_image_card_mid_left">
                  <p>Content Writting</p>
                  <i class="fa fa-arrow-right"></i>
                </div>
              </div>
            </div>
            <div className="service_container_image_card">
              <div className="service_container_image_card_img">
                <img src={img3} alt="" />
              </div>
              <div className="service_container_image_card_mid">
                <div className="service_container_image_card_mid_left">
                  <p>Graphic Design</p>
                  <i class="fa fa-arrow-right"></i>
                </div>
              </div>
            </div>
            <div className="service_container_image_card">
              <div className="service_container_image_card_img">
                <img src={img4} alt="" />
              </div>
              <div className="service_container_image_card_mid">
                <div className="service_container_image_card_mid_left">
                  <p>SEO for Business</p>
                  <i class="fa fa-arrow-right"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="choose">
        <div className="choose_container">
          <div className="choose_container_heading">
            <h4>Why you should choose us?</h4>
            <p>
              with lots of unique blocks, you can easily build a page without{" "}
              <br></br>coding . Build your next landing page.
            </p>
          </div>
          <div className="choose_container_contents">
            <div className="choose_container_contents_left">
              <img src={choose} alt="" />
            </div>
            <div className="choose_container_contents_right">
              <div className="choose_container_contents_right_sec">
                <div className="choose_container_contents_right_num">
                <h1>1</h1>
                </div>
                <div className="choose_container_contents_right_content">
                  <h2>Easy Booking</h2>
                  <p>
                    With loots of unique blocks , you can easily build a page
                    without coding.
                  </p>
                </div>
              </div>
              <div className="choose_container_contents_right_num">
                <h1>2</h1>
                <div className="choose_container_contents_right_content">
                  <h2>Free Expert Opinion</h2>
                  <p>
                    With lots of unique blocks, you can easily build a page
                    without coding.
                  </p>
                </div>
              </div>
              <div className="choose_container_contents_right_num">
                <h1>3</h1>
                <div className="choose_container_contents_right_content">
                  <h2>Get Your Results</h2>
                  <p>
                    With lots of unique blocks, you can easily build a page
                    without coding
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="choose_sub">
        <p>
          <span>NEW </span>
          We'vw added a new exciting features in v3.0 <u>Get it now for $49.</u>
        </p>
      </div>
      <div className="review">
        <div className="review_container">
          <div className="review_container_left">
            <div className="review_container_left_icon">
              <img src={logo} alt="" />
            </div>
            <div className="review_container_left_contents">
              <h4>
                "You made it so simple. My new site is so much faster and easier
                to work with Albino."
              </h4>
            </div>
            <div className="review_container_left_contents_name">
              <img src={pic} alt="" />
              <div className="review_container_left_contents_name_num">
                <h5>IIly vasin</h5>
                <h6>Software engineer</h6>
              </div>
            </div>
          </div>
          <div className="review_container_mid">
            <div className="review_container_mid_icon">
              <img src={logo1} alt="" />
            </div>
            <div className="review_container_mid_contents">
              <h4>
                "Must have book for students, who want to be a great Product
                Designer."
              </h4>
            </div>
            <div className="review_container_mid_contents_name">
              <img src={pic1} alt="" />
              <div className="review_container_mid_contents_name_num">
                <h5>Mariano Rasg</h5>
                <h6>Software engineer</h6>
              </div>
            </div>
          </div>
          <div className="review_container_right">
            <div className="review_container_right_icon">
              <img src={logo} alt="" />
            </div>
            <div className="review_container_right_contents">
              <h4>
                "You made it so simple. My new site is so much faster & easier
                to work with Albino."
              </h4>
            </div>
            <div className="review_container_right_contents_name">
              <img src={pic2} alt="" />
              <div className="review_container_right_contents_name_num">
                <h5>Oka Tomaaki</h5>
                <h6>Software engineer</h6>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="consult">
        <div className="consult_container">
          <div className="consult_container_left">
            <div className="consult_container_left_icon">
              <i class="fa fa-comment"></i>
            </div>
            <div className="consult_container_left_heading">
              <h4>Get a free consultancy from our expert right now!</h4>
              <p>
                With lots of unique blocks, you can easily build a page without
                coding. Build a next landing page so quickly with Albino.
              </p>
            </div>
          </div>
          <div className="consult_container_right">
            <div className="consult_container_right_container">
            <div className="consult_container_right_container_tabs">
              <h5>Name</h5>
              <input
                type="text"
                placeholder="i.e. john Doe"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
              />
              {validationErrors.name && (
                <span className="error-message">{validationErrors.name}</span>
              )}

              <h5>Email</h5>
              <input
                type="text"
                placeholder="i.e.john@mail.com"
                name="emailAddress"
                value={formData.emailAddress}
                onChange={handleInputChange}
              />
              {validationErrors.email && (
                <span className="error-message">{validationErrors.email}</span>
              )}

              <h5>Phone</h5>
              <input
                type="text"
                name="phone"
                placeholder="i.e. 123-456-7890"
                value={formData.phone}
                onChange={handleInputChange}
              />
              {validationErrors.phone && (
                <span className="error-message">{validationErrors.phone}</span>
              )}

              <h5>Which service do you need? </h5>
              <input
                type="text"
                name="service"
                placeholder="select a service"
                value={formData.service}
                onChange={handleInputChange}
              />
              {validationErrors.service && (
                <span className="error-message">
                  {validationErrors.service}
                </span>
              )}

              <div className="consult_container_right_container_button">
                <button onClick={handleSubmit}>Get free consultancy </button>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="subscribe">
        <div className="subscribe_container">
          <div className="subscribe_container_contents">
            <h2>
              Subscribe to our newsletter to get latest news on your inbox.
            </h2>
            <div className="subscribe_container_contents_button">
              <input
                type="text"
                className="email"
                placeholder="Enter your email"
              />
              <button>
                Subscribe <i class="fa fa-arrow-right"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
