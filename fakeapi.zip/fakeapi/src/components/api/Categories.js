import React, { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table';

const Api = () => {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    fetch('https://fakestoreapi.com/products/categories')
      .then(res => res.json())
      .then(json => setCategories(json))
      .catch(error => {
        console.error('Error fetching categories:', error);
      });
  }, []);

  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>Category</th>
        </tr>
      </thead>
      <tbody>
        {categories.map((category, index) => (
          <tr key={index}>
            <td>{category}</td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}

export default Api;
