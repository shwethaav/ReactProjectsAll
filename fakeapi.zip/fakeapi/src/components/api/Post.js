import React, { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table';
import axios from 'axios';

const Api = () => {
  const [data, setData] = useState([]);
  const [clickedId, setClickedId] = useState(null); 

  useEffect(() => {
    axios.post('https://fakestoreapi.com/products', {
      title: 'test product',
      price: 13.5,
      description: 'lorem ipsum set',
      image: 'https://i.pravatar.cc',
      category: 'electronics' 
    })
      .then(response => {
        console.log('Product added:', response.data);
        setData([response.data]);
      })
      .catch(error => {
        console.error('Error adding product:', error);
      });
  }, []);

  const handleEdit = (id, title, price, description, category, image) => {
    console.log('Edit button clicked for product:', id);
    console.log('Product details:', { id, title, price, description, category, image });
    
    axios.put(`https://fakestoreapi.com/products/${id}`, {
      title: 'updated product', 
      price: 15.5,
      description: 'updated description', 
      image: 'https://i.pravatar.cc',
      category: 'updated category'
    })
      .then(response => {
        console.log('Updated product:', response.data);
        setData([response.data]); 
      })
      .catch(error => {
        console.error('Error updating product:', error);
      });
  };
  
  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>#</th>
          <th>Title</th>
          <th>Price</th>
          <th>Category</th>
          <th>Description</th>
          <th>Image</th>
          <th>Edit</th>
        </tr>
      </thead>
      <tbody>
        {data.map(eachData => (
          <tr key={eachData.id}>
            <td>{eachData.id}</td>
            <td>{eachData.title}</td>
            <td>{eachData.price}</td>
            <td>{eachData.category}</td>
            <td>{eachData.description}</td>
            <td>
              <img
                src={eachData.image}
                alt={eachData.title}
                style={{ width: '50px', height: '50px' }}
              />
            </td>
            <td>
              <i 
                className={`fa fa-pencil${clickedId === eachData.id ? ' clicked' : ''}`} 
                onClick={() => handleEdit(eachData.id, eachData.title, eachData.price, eachData.description, eachData.category, eachData.image)}
              ></i>
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}

export default Api;
