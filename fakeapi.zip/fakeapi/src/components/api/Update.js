import React, { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table';
import axios from 'axios';

const Api = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch('https://fakestoreapi.com/products/7',{
        method:"PUT",
        body:JSON.stringify(
            {
                title: 'test product',
                price: 13.5,
                description: 'lorem ipsum set',
                image: 'https://i.pravatar.cc',
                category: 'electronic'
            }
        ),
        headers: {
          'Content-Type': 'application/json'
        }
    })
        .then(res => res.json())
        .then(updatedProduct => {
          console.log('Updated product:', updatedProduct);
          setData([updatedProduct]); 
        })
        .catch(error => {
          console.error('Error updating product:', error);
        });
  }, []);

  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>#</th>
          <th>Title</th>
          <th>Price</th>
          <th>Category</th>
          <th>Description</th>
          <th>Image</th>
        </tr>
      </thead>
      <tbody>
        {data.map(eachData => (
          <tr key={eachData.id}>
            <td>{eachData.id}</td>
            <td>{eachData.title}</td>
            <td>{eachData.price}</td>
            <td>{eachData.category}</td>
            <td>{eachData.description}</td>
            <td>
              <img
                src={eachData.image}
                alt={eachData.title}
                style={{ width: '50px', height: '50px' }}
              />
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}

export default Api;
