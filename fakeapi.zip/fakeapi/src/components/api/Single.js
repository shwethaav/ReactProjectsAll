import React, { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table';
// import axios from 'axios';

const Api = () => {
  const [data, setData] = useState({});

  useEffect(() => {
    fetch('https://fakestoreapi.com/products/7')
      .then(res => res.json())
      .then(json => setData(json))
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);

  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>#</th>
          <th>Title</th>
          <th>Price</th>
          <th>Category</th>
          <th>Description</th>
          <th>Image</th>
        </tr>
      </thead>
      <tbody>
        <tr key={data.id}>
          <td>{data.id}</td>
          <td>{data.title}</td>
          <td>{data.price}</td>
          <td>{data.category}</td>
          <td>{data.description}</td>
          <td>
            <img src={data.image} alt={data.title} style={{ width: '50px', height: '50px' }} />
          </td>
        </tr>
      </tbody>
    </Table>
  );
}

export default Api;
