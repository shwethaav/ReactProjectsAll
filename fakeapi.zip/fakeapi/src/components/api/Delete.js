import React, { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table';
import axios from 'axios';

const Api = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.delete('https://fakestoreapi.com/products/6') 
      .then(res => {
        setData([res.data]);
      })
      .catch(error => {
        console.error('Error deleting data:', error);
      });
  }, []);

  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>#</th>
          <th>Title</th>
          <th>Price</th>
          <th>Category</th>
          <th>Description</th>
          <th>Image</th>
        </tr>
      </thead>
      <tbody>
        {data.map((eachData) => (
          <tr key={eachData.id}>
            <td>{eachData.id}</td>
            <td>{eachData.title}</td>
            <td>{eachData.price}</td>
            <td>{eachData.category}</td>
            <td>{eachData.description}</td>
            <td>
              <img src={eachData.image} alt={eachData.title} style={{ width: '50px', height: '50px' }} />
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}

export default Api;
