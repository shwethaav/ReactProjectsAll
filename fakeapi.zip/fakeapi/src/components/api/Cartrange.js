import React, { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table';
// import axios from 'axios';

const Api = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch('https://fakestoreapi.com/carts')
      .then(res => res.json())
      .then(json => {
        
        const filteredData = json.filter(cart => {
          const cartDate = new Date(cart.date);
          return cartDate >= new Date('2019-12-10') && cartDate <= new Date('2020-10-10');
        });
        setData(filteredData);
      })
      .catch(error => {
        console.error('Error fetching cart data:', error);
      });
  }, []);
  
  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>#</th>
          <th>Title</th>
          <th>Price</th>
          <th>Category</th>
          <th>Description</th>
          <th>Image</th>
        </tr>
      </thead>
      <tbody>
        {data.map(eachData => (
          <tr key={eachData.id}>
            <td>{eachData.id}</td>
            <td>{eachData.title}</td>
            <td>{eachData.price}</td>
            <td>{eachData.category}</td>
            <td>{eachData.description}</td>
            <td>
              <img
                src={eachData.image}
                alt={eachData.title}
                style={{ width: '50px', height: '50px' }}
              />
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}

export default Api;
