import React from "react";
import { BrowserRouter as Router, Routes, Route} from "react-router-dom";
import Api from '..//components/api/Api';
// import { Delete } from "react-axios";
import Delete from '..//components/api/Delete';
import Single from '..//components/api/Single';
import Limit from '..//components/api/Limit';
import Categories from '..//components/api/Categories';
import Post from '..//components/api/Post';
import Update from '..//components/api/Update';
import Cartrange from '..//components/api/Cartrange';
const RouterComponent = () => {
  return (
    <Router>
    
            <Routes>
            <Route path="/" element = {<Api/>} />
            <Route path="/delete" element = {<Delete/>} />
            <Route path="/single" element = {<Single/>} />
            <Route path="/limit" element = {<Limit/>} />
            <Route path="/categories" element = {<Categories/>} />
            <Route path="/post" element = {<Post/>} />
            <Route path="/update" element = {<Update/>} />
            <Route path="/cartrange" element = {<Cartrange/>} />
            </Routes>
    </Router>
  );
};

export default RouterComponent;
