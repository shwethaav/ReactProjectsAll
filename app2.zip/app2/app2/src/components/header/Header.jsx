import React, { useState } from "react";
import "./Header.scss";
import logo from "..//..//assets/headerLogo.png";
const Header = () => {
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const handleMobileMenu = () => {
    setShowMobileMenu(!showMobileMenu);
  };
  return (
    <div>
      <div className="header">
        <div className="header_container">
          <div className="header_logo">
            <img src={logo} alt="" />
          </div>
          <div className="header_menu">
            <ul>
              <li>HOME</li>
              <li>ABOUT</li>
              <li>BENEFITS</li>
              <li>TOKENSAIL</li>
              <li>ROADMAP</li>
              <li>DOWNLOADS</li>
              <li>FAQS</li>
              <li >CONTACT</li>
              <li>PAGES</li>
            </ul>
          </div>
          <div className="header_menu_mobile">
            <div className="header_menu_mobile_icon">
              <i class="fa fa-bars" onClick={handleMobileMenu}></i>
            </div>

            {showMobileMenu && (
              <div className="header_menu_mobile_menulist">
                <ul>
                  <li>Home</li>
                  <li>About</li>
                  <li>Benefits</li>
                  <li>Tokensail</li>
                  <li>Roadmap</li>
                  <li>Downloads</li>
                  <li>Faqs</li>
                  <li>Pages</li>
                  <button className="btn1">LOGIN</button>
            <button className="btn2">SIGNUP</button>
                </ul>
              </div>
            )}
          </div>
          <div className="header_buttons">
            <button className="btn1">LOGIN</button>
            <button className="btn2">SIGNUP</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
