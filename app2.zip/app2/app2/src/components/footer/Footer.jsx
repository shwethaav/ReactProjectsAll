import React from "react";
import "./Footer.scss";
import logo from "..//..//assets/headerLogo.png";
import twitter from "..//..//assets/images/images/footerTwitter.png";
import teligram from "..//../assets/images/images/footerTelegram.png";
import discord from "..//..//assets/images/images/footerDiscord.png";
import youtube from "..//../assets/images/images/footerYoutube.png";
import medium from "..//..//assets/images/images/fotterMedium.png";
import linkedin from "..//..//assets/images/images/footerLinkdIn.png";

const Footer = () => {
  return (
    <div>
      <div className="footer">
        <div className="footer_container">
          {/* <div className="footer_container_headings">
            <ul>
              <li className='menu'>MENU</li>
              <li className='papers'>PAPERS</li>
              <li className='legal'>LEGAL</li>
              <li className='news'>NEWSLETTER</li>
            </ul>
          </div> */}
          <div className="footer_container_lists">
            <div className="footer_container_lists_menu">
              <ul>
                <li className="menu">MENU</li>
                <li>About</li>
                <li>Team</li>
                <li>Contact</li>
                <li>Blog</li>
              </ul>
            </div>
            <div className="footer_container_lists_papers">
              <ul>
                <li className="papers">PAPERS</li>
                <li>White Paper</li>
                <li>Technology Paper</li>
                <li>One Pager</li>
              </ul>
            </div>
            <div className="footer_container_lists_legal">
              <ul>
                <li className="legal">LEGAL</li>
                <li>Privacy Policy</li>
                <li>Terms & Conditions</li>
                <li>Cookie Policy</li>
              </ul>
            </div>
            <div className="footer_container_lists_buttons">
              <li className="news">NEWSLETTER</li>
              <input type="email" placeholder="Email address" />
            </div>
          </div>
          <div className="footer_container_logos">
            <div className="footer_container_logos_left">
              <img src={logo} alt="" />
            </div>
            <div className="footer_container_logos_right">
              <p>Our Socilas</p>
              <img src={twitter} alt="" />
              <img src={teligram} alt="" />
              <img src={discord} alt="" />
              <img src={youtube} alt="" />
              <img src={medium} alt="" />
              <img src={linkedin} alt="" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
