import React from "react";
import "./Home.scss";
import twitter from "..//..//assets/images/images/footerTwitter.png";
import teligram from "..//..//assets/images/images/footerTelegram.png";
import discord from "..//..//assets/images/images/footerDiscord.png";
import youtube from "..//..//assets/images/images/footerYoutube.png";
import medium from "..//..//assets/images/images/footerTikTok.png";
import linkedin from "..//..//assets/images/images/footerLinkdIn.png";
import amb from "..//..//assets/images/images/ambcrypto.png.png";
import bein from "..//..//assets/images/images/beincrypto.png.png";
import bit from "..//..//assets/images/images/bitcoinist.png.png";
import bloom from "..//..//assets/images/images/bloomberg.png.png";
import coin from "..//..//assets/images/images/Cointelegraph.png.png";
import news from "..//..//assets/images/images/NewsBTC.png.png";
import NFT from "..//..//assets/images/images/NFTMarketplace.png";
import stak from "..//..//assets/images/images/Staking.png";
import gov from "..//..//assets/images/images/Governance.png";
import paper from "..//..//assets/images/images/whitepaper.png";
import Fade from "react-reveal/Fade";
import Flip from "react-reveal/Flip";
import Slide from "react-reveal/Slide";
import Reveal from "react-reveal/Reveal";
import Zoom from "react-reveal/Zoom";
import Bounce from "react-reveal/Bounce";
import LightSpeed from "react-reveal/LightSpeed";

const Home = () => {
  return (
    <div>
      <div className="home">
        <div className="home_banner">
          <div className="home_banner_contents">
            <Fade left>
              <div className="home_banner_contents_box1">
                <p>
                  Invest in the<br></br> <span>Future of AI technology</span>
                  <br></br>
                  with <span style={{ color: "#FFB904" }}> Global Enerygy</span>
                </p>
                <div className="home_banner_contents_box1_icons">
                  <img src={twitter} alt="" />
                  <img src={teligram} alt="" />
                  <img src={discord} alt="" />
                  <img src={youtube} alt="" />
                  <img src={medium} alt="" />
                  <img src={linkedin} alt="" />
                </div>
              </div>
            </Fade>
            <div className="home_banner_contents_box2">
              <Fade right>
                <button className="btn1" input type="text">
                  BUY TOKENS
                </button>
                <p>Use Promo code to get 10% bonus!</p>
                <p>Enter a promo code</p>
                <div className="home_banner_contents_box2_buttons">
                  <button className="btn2"></button>
                  <button className="btn3">Apply code</button>
                </div>
              </Fade>
              <div className="home_banner_contents_box2_content">
                <h5>
                  <u>HOW TO BUY?</u>
                </h5>
              </div>
            </div>
          </div>
        </div>
        <div className="home_logos">
          <div className="home_logos_content">
            <Fade left>
              <p>As Featured in:</p>
            </Fade>
          </div>
          <div className="home_logos_logo">
            <Flip left>
              <img src={amb} alt="" />
              <img src={bein} alt="" />
              <img src={bit} alt="" />
              <img src={bloom} alt="" />
              <img src={coin} alt="" />
              <img src={news} alt="" />
            </Flip>
          </div>
        </div>

        <div className="home_container">
          <div className="home_container_section">
            <div className="home_container_section_heading">
              <Slide left>
                <h4>
                  What is<span> Global Energy?</span>
                </h4>{" "}
              </Slide>
            </div>
            <Reveal effect="fadeInUp">
              <p>
                Lorem ipsum dolor sit amet consectetur.Id tempus nec condimentum
                sed urna.In non placerat elementum<br></br>Iorem hac maecenas
                sodales nunc.Posuere arcu amet vel ut sed.Ultricies lacus
                curabitur velit urna pretium<br></br>
                et tempus vitae malesuada.<br></br>
                Lorem ipsum dolor sit amet consectertur.Id tempus nec
                condimentum sed urna.In non placerat elementum<br></br> lorem
                hac maecenas sodales nunc. Posuere arcu amet ve
              </p>
            </Reveal>
            <div className="home_container_section_buttons">
              <button className="btn1">READ MORE</button>
              <button className="btn2">BUY $QUBE</button>
            </div>
          </div>
        </div>
        <div className="home_tokens">
          <div className="home_tokens_container">
            <div className="home_tokens_container_heading">
              <Zoom left>
                <h1>ICOX Tokens</h1>
                <p>
                  Our Tokens with a realworld use created on the blockchain
                  network.
                </p>
              </Zoom>
            </div>
            <div className="home_tokens_container_info">
              <div className="home_tokens_container_info_main">
                <div className="home_tokens_container_info_box1">
                  <div className="home_tokens_container_info_box1_heading">
                    <h4>Sales Information</h4>
                  </div>
                  <div className="home_tokens_container_info_box1_contents">
                    <ul>
                      <li>
                        <span className="name">Public Sale Start</span>
                        <span className="date">11/01/2024</span>
                      </li>
                      <li>
                        <span className="name">Public Sale Ends</span>
                        <span className="date">20/01/2024</span>
                      </li>
                      <li>
                        <span className="name">Total Token Supply</span>
                        <span className="date">500,000,000</span>
                      </li>
                      <li>
                        <span className="name">Token allocate for ICO</span>
                        <span className="date">350,000,000</span>
                      </li>
                      <li>
                        <span className="name">Hard Cap</span>
                        <span className="date">$4.75m</span>
                      </li>
                      <li>
                        <span className="name">Soft Cap</span>
                        <span className="date">$1.75m</span>
                      </li>
                      <li>
                        <span className="name">Accepted</span>
                        <span className="date">BTC,ETH</span>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="home_tokens_container_info_box2">
                  <div className="home_tokens_container_info_box2_contents">
                    <div className="home_tokens_container_info_box2_contents_current">
                      <div className="home_tokens_container_info_box2_contents_current_left">
                        <p>Current Stage</p>
                        <h5>Stage 7</h5>
                      </div>
                      <div className="home_tokens_container_info_box2_contents_current_right">
                        <p>Total Raised</p>
                        <h5>$8,153,444.33</h5>
                      </div>
                    </div>
                    <div className="home_tokens_container_info_box2_contents_progress">
                      <div className="home_tokens_container_info_box2_contents_progress_top">
                        <div className="home_tokens_container_info_box2_contents_progress_top_one">
                          <i class="fa-thin fa-angles-up"></i>
                          <h5>83.7% Sold</h5>
                        </div>
                        <div className="home_tokens_container_info_box2_contents_progress_top_two">
                          <p>109,688,180</p>
                          <h6>Remaining</h6>
                        </div>
                      </div>

                      <div className="home_tokens_container_info_box2_contents_progress_bar">
                        <div className="home_tokens_container_info_box2_contents_progress_bar_p1"></div>
                        <div className="home_tokens_container_info_box2_contents_progress_bar_p2"></div>
                      </div>
                      <div className="home_tokens_container_info_box2_contents_progress_top_contents">
                        <div className="home_tokens_container_info_box2_contents_progress_top_contents_left">
                          <p>
                            <span>0.0224</span> USDT=1$QUBE
                          </p>
                        </div>
                        <div className="home_tokens_container_info_box2_contents_progress_top_contents_right">
                          <p>Next Stage:0.0255</p>
                        </div>
                      </div>
                    </div>
                    <div className="home_tokens_container_info_box2_contents_name">
                      <p>
                        <span>715,656,134</span> Token Sold
                      </p>
                    </div>
                    <div className="home_tokens_container_info_box2_contents_button">
                      <button>BUY TOKENS</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="home_cube">
          <div className="home_cube_container">
            <div className="home_cube_container_heading">
              <Bounce left>
                <p>
                  Unlocking the power of <br></br>
                  <span>Ai innovation with Qube</span>
                </p>
              </Bounce>
            </div>
            <div className="home_cube_container_box">
              <div className="home_cube_container_box_left">
                <Zoom left>
                  <h3>NFT Marketplace</h3>
                  <p>
                    Lorem ipsum sit amet consectetur.Condimentum ut dictum nunc
                    netus cum sec.Amet id eu curabitur facilisis tristique lacus
                    suspendisse tempor.Scelerisque feugiat ut phasellus mattis
                    consectetur.Rutrum vitae id eu etiam porta arcu fusce ut.
                  </p>
                </Zoom>
              </div>
              <div className="home_cube_container_box_right">
                <Fade right>
                  <img src={NFT} alt="" />
                </Fade>
              </div>
            </div>
            <div className="home_cube_container_box">
              <div className="home_cube_container_box_left">
                <Fade right>
                  <h3>Staking</h3>
                  <p>
                    Lorem ipsum sit amet consectetur.Condimentum ut dictum nunc
                    netus cum sec.Amet id eu curabitur facilisis tristique lacus
                    suspendisse tempor.Scelerisque feugiat ut phasellus mattis
                    consectetur.Rutrum vitae id eu etiam porta arcu fusce ut.
                  </p>
                </Fade>
              </div>
              <div className="home_cube_container_box_right">
                <Zoom left>
                  <img src={stak} alt="" />
                </Zoom>
              </div>
            </div>
            <div className="home_cube_container_box">
              <div className="home_cube_container_box_left">
                <Fade right>
                  <h3>Governance</h3>
                  <p>
                    Lorem ipsum sit amet consectetur.Condimentum ut dictum nunc
                    netus cum sec.Amet id eu curabitur facilisis tristique lacus
                    suspendisse tempor.Scelerisque feugiat ut phasellus mattis
                    consectetur.Rutrum vitae id eu etiam porta arcu fusce ut.
                  </p>
                </Fade>
              </div>
              <div className="home_cube_container_box_right">
                <Zoom left>
                  <img src={gov} alt="" />
                </Zoom>
              </div>
            </div>
          </div>
        </div>
        <div className="home_ai">
          <div className="home_ai_container">
            <div className="home_ai_container_heading">
              <Fade right>
                <h2>
                  AI Starts-Ups <span>Apply</span>{" "}
                </h2>
              </Fade>
            </div>
            <div className="home_ai_container_contents">
              <Zoom top>
                <h5>
                  Are you an Ai start-up looking to raise funds with your
                  community?
                </h5>
                <p>
                  Our NFT marketplace provides an innovative way to mint
                  investment opportunities into NFTs, which can be listed on our
                  platform for $QUBE token holders to invest in. Apply via our
                  online form for a chance to be listed and gain access to our
                  passionate community of investors who are dedicated to
                  supporting the growth of AI technology.
                </p>
              </Zoom>
            </div>
            <div className="home_ai_container_buttons">
              <LightSpeed top>
                <button className="btn1">Apply</button>
                <button className="btn2">Buy $QURE</button>
              </LightSpeed>
            </div>
          </div>
        </div>
        <div className="home_global">
          <div className="home_global_container">
            <div className="home_global_container_left">
              <Slide left>
                <div className="home_global_container_left_heading">
                  <h4>
                    Global Energy <span>Whitepapers</span>
                  </h4>
                  <div className="home_global_container_left_contents">
                    <p>
                      Lorem ipsum dolor sit consectetur. Id tempus nec
                      condimentum sed urna.In non placerat ellementum lorem hac
                      maecenas sodales nunc. Posuere arcu amet vel ut sed.
                      Ultricieslacus curabitur velit urna pretium state tempus
                      vitae malesuada.<br></br>
                      Lorem ipsum dolor sit amet consectetur . Id
                      tempuscondimentum sed urna. In non placerat elementum
                      lorem hac maecenas nunc. Posuere arcu ve
                    </p>
                    <div className="home_global_container_left_contents_buttons">
                      <button className="btn1">READ MORE</button>
                      <button className="btn2">BUY $QUBE</button>
                    </div>
                  </div>
                </div>
              </Slide>
            </div>
            <div className="home_global_container_right">
              <Zoom top>
                <img src={paper} alt="" />
              </Zoom>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
