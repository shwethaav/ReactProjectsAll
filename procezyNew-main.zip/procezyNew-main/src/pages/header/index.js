import React, { useState } from 'react';
import logo from '../../assets/images/logo.png';
import './index.scss';
import { HashLink } from 'react-router-hash-link';
// import { useHistory } from 'react-router';
// import ReactTooltip from 'react-tooltip';
import Tooltip from '@mui/material/Tooltip';
// import { NavLink } from 'react-router-dom';
// import { Link, Button, Element, Events, animateScroll as scroll, scrollSpy, scroller } from 'react-scroll'
import { Link } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';

const Header = () => {
    const [isNavExpanded, setIsNavExpanded] = useState(false)
    const [alertText, setAlertText] = useState('');

    const closeMenu = () => {
        setIsNavExpanded(false);
    }

    // const handleClick = () => {
    //     // toast('Launching Soon');
    //     setAlertText('Thank You For Contacting Us We Will Get Back to You Soon')
    // }
    // const history = useHistory();

    // const scrollView = () => {
    //     history.push('/')
    //     window.scrollTo(0, 0);
    //     window.location.reload();
    //     const window = document.getElementById('contact-us');
    //     window.scrollIntoView({ behavior: 'smooth' });
    // }

    //   function scrollView() {
    //     const mainRoot = document.getElementById("/contact-us");
    //     mainRoot.scrollIntoView({ behavior: "smooth" });
    //   }

    // const handleClickHome = () => {
    //     history.push('/')
    //     window.location.reload();
    // };

    const handleClickScroll = () => {
        window.scrollTo(0, 0);
    };

    // const handleAboutUs = () => {
    //     history.push('/FAQs')
    //     window.location.reload();
    //     window.scrollTo(0, 0);
    // };

    // var prevScrollpos = window.pageYOffset;
    // window.onscroll = function () {
    //     var currentScrollPos = window.pageYOffset;
    //     if (prevScrollpos > currentScrollPos) {
    //         document.getElementById("navbar").style.top = "0";
    //     } else {
    //         document.getElementById("navbar").style.top = "-115px";
    //     }
    //     prevScrollpos = currentScrollPos;
    // }

    return (
        <div>
            <div className='header fixed-header fixed-top' id='navbar' >
                <nav className='navigation'>
                    <a className='header-name' onClick={closeMenu}>
                        <Link to='/' onClick={handleClickScroll}>
                            <img src={logo} alt='' />
                        </Link>
                    </a>
                    <div className={
                        isNavExpanded ? 'header-menu expanded' : 'header-menu'
                    }>
                        <ul onClick={() => {
                            setIsNavExpanded(!isNavExpanded);
                        }}>
                            <li style={{ cursor: 'pointer' }} className='nav-link'>
                                {/* <NavLink to='/about-us' activeStyle={{ color: '#00aff0', textDecoration: 'none' }} exact className='nav-link'>FAQs
                                </NavLink> */}
                                {/* <a href='/FAQs'>FAQs</a> */}
                                <Link to='/faqs' onClick={handleClickScroll}>FAQs</Link>
                                {/* <a>FAQs</a> */}
                            </li>
                            <li>
                                {/* <Link to='/#contact-us'> */}
                                <HashLink smooth to='/#contact-us' style={{ cursor: 'pointer' }}>
                                    Contact Us
                                </HashLink>
                                {/* </Link> */}
                                {/* <Link to='contact-us' spy={true} smooth={true} duration={500}>
                                Contact Us
                                </Link> */}
                                {/* <HashLink smooth to='#contact-us' style={{ cursor: 'pointer' }}>Contact Us</HashLink> */}
                                {/* <HashLink onClick={scrollView} style={{ cursor: 'pointer' }} className='nav-link'>
                                Contact Us
                            </HashLink>  */}
                            </li>
                            <Tooltip title='Launching Soon' placement='bottom'>
                                <button className='button-mb'>Sign up</button>
                            </Tooltip>
                        </ul>
                        <Tooltip className='toottip-header' title='Launching Soon' placement='bottom'>
                            <button className='button-lap'>Sign up</button>
                        </Tooltip>
                    </div>
                    <button onClick={() => {
                        setIsNavExpanded(!isNavExpanded);
                    }}
                        className='hamburger'>
                        <svg xmlns="http://www.w3.org/2000/svg"
                            className="h-5 w-5" viewBox="0 0 20 20" fill="white">
                            <path fillRule="evenodd"
                                d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM9 15a1 1 0 011-1h6a1 1 0 110 2h-6a1 1 0 01-1-1z"
                                clipRule="evenodd" />
                        </svg>
                    </button>
                </nav>
            </div>
            {/* <ToastContainer
                position="top-center"
                autoClose={5000}
                // delayUpdate={1000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                // pauseOnFocusLoss
                draggable
                // pauseOnHover
                theme="light"
                limit={1}
            /> */}
        </div>
    )
}

export default Header;