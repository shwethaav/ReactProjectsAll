import React, { useEffect } from 'react';
import './index.scss';
import {
    ExpansionList,
    ExpansionPanel,
    usePanels,
} from '@react-md/expansion-panel';

const FAQs = (props) => {

    useEffect(() => {
        document.title = props.title;

        return () => {
            console.log('This will be logged on unmount');
        };
    }, []);

    const [panels, onKeyDown] = usePanels({
        count: 18,
        idPrefix: "configuring-panels",
    });


    return (
        <div>
            <div className='help'>
                <h1>FAQs</h1>
                <div className='help__container'>
                    <ExpansionList onKeyDown={onKeyDown}>
                        <ExpansionPanel {...panels[0]} header='1. What is ProcEzy?'
                            expandIcon="fa fa-plus"
                            collapseIcon="fa fa-minus">
                            <h5>ProcEzy is India’s 1st marketplace designed for the IT Channel Partner ecosystem members. The marketplace is accessible to registered members only. <span> REGISTRATION IS FREE</span> to all “IT Channel Partner Ecosystem members”.</h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[1]} header='2. What do you mean by IT Channel Partner Ecosystem members?'>
                            <h5>An IT channel partner ecosystem includes all the businesses that are established with the goal to market, sell, service, and support, IT products, software solutions, and
                                services to customers. An example of all the IT Channel Partner ecosystem members is
                                given below. </h5>

                            <ul>
                                <h6><li>1. Hardware Reseller </li></h6>
                                <h6><li>2. System Integrator </li></h6>
                                <h6><li>3. Value Added Reseller </li></h6>
                                <h6><li>4. Local Original Equipment Manufacturer</li></h6>
                                <h6><li>5. Network Solutions Provider </li></h6>
                                <h6><li>6. Network Systems Integrator </li></h6>
                                <h6><li>7. Local Distributor </li></h6>
                                <h6><li>8. Regional Distributor  </li></h6>
                                <h6><li>9. Managed Service Provider </li></h6>
                            </ul>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[2]} header='3. What does ProcEzy do?'>
                            <h5>ProcEzy makes the process of Buying and Selling IT products between partners easier by connecting channel partners across India on a single platform. </h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[3]} header='4. Is ProcEzy Free to use? '>
                            <h5><span>Yes</span>, ProcEzy is free to use for all registered IT Channel Partner Ecosystem members. </h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[4]} header='5. Does ProcEzy charge any commission to SELL or BUY on the platform?'>
                            <h5><span>NO.</span> ProcEzy does not charge any commission for Selling or Buying on the platform. </h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[5]} header='6. Should my organization be registered with the GST department to complete registration with ProcEzy?'>
                            <h5>Yes, ProcEzy requires that its users (organizations) are <span>GST</span> registered.</h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[6]} header='7. How does  ProcEzy work?'>
                            <h5>Only IT Channel Partner Ecosystem members can register their organization as a <span>BUYER</span> or <spn>SELLER</spn>. </h5>

                            <h5>Once their registration is approved by the marketplace administrator, they can start
                                using the marketplace to: </h5>
                            <ul>
                                <h6><li>1. As a <span>BUYER</span> - search for IT products that they need to source from other partners.</li></h6>
                                <h6><li>2. As a <span>SELLER</span> - sell IT products to other partners who are searching for IT products to meet their business demands.</li></h6>
                            </ul>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[7]} header='8. How do I register at ProcEzy?'>
                            <h5>You can visit the ProcEzy website <a href='https://developer.procezy.com' target='_blank'>procezy.com </a>and select the “Sign Up” option. Here you will find “Register as a Buyer” and “Register as a Seller”. You can
                                choose the type of role and start your registration process. </h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[8]} header='9. How does the BUYER role work?'>
                            <h5>ProcEzy maintains a vast and growing database of IT products which is categorized by Product Type, Manufacturers, Models & various SKUs under each model. </h5>


                            <h6>A <span>BUYER</span> can search for a product from the ProcEzy database and they will be shown a
                                list of <span>SELLERS</span> who are selling the product on ProcEzy. </h6>
                            <ul>
                                <h6><li>- The <span>BUYER</span> can choose the seller depending on the prices and availability of the
                                    product. </li></h6>
                                <h6><li>- The <span>BUYER</span> can chat directly with the <span>SELLER</span> organization and negotiate better
                                    pricing directly with the <span>SELLER</span>. Orders can be confirmed over the chat interface and
                                    order tracking can be followed to track delivery status of the products by the <span>SELLER</span>.
                                </li></h6>
                            </ul>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[9]} header='10. How does the SELLER role work?'>
                            <h5>The <span>SELLER</span> will add the list of products they intend to sell on ProcEzy from the ProcEzy Database and update their selling price regularly.  </h5>
                            <h5>Whenever a BUYER searches for a product, the ProcEzy search engine will search for all <span>SELLERS</span> who sell the required product and list out all the <span>SELLERS</span> to the BUYER. This search result is displayed based on “Lowest Price First”.  </h5>
                            <h5>The BUYERS can choose the <span>SELLERS</span> they want to work with and send them an enquiry or confirm orders with them. </h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[10]} header='11. I am a BUYER from Bangalore and none of the suppliers have stock of the product in Bangalore. How can ProcEzy help me?'>
                            <h5>ProcEzy can help you to extend your search to other cities across India and connect you with <span>SELLERS</span> who have stock of the product or are selling this product.  With this feature, you will be able to connect with many <span>SELLERS</span> across the country to get the best prices and improve your business. </h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[11]} header=' 12. I am a SELLER from Mumbai and I have a stock of some products with good pricing, but I am unable to sell my inventory as I don’t know the BUYERS who are purchasing this product. How can ProcEzy help me?'>
                            <h5>Whenever a <span>BUYER</span> searches for a product and chooses “Pan-India” as their search location, All <span>SELLERS</span> having the product as part of their <span>SALES-CATALOGUE</span> will be shown to the <span>BUYER</span> in the search results and the <span>BUYER</span> will be able to directly communicate over chat with the <span>SELLER</span> without any interference or restrictions by the ProcEzy marketplace. </h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[12]} header='13. I am a System Integrator and I need product pricing to quote for a project. How can ProcEzy help me?'>
                            <h5>You can search through the ProcEzy database for the required products and check the prices offered by <span>SELLERS</span> in your location or across the country. This should help you with pricing to make your proposal. </h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[13]} header='14. Today is a weekend and I need product pricing urgently. The requirement came up at the last minute. How can ProcEzy help me?'>
                            <h5>ProcEzy is an Online Marketplace and is accessible 24x7 to registered members. On ProcEzy, <span>SELLERS</span> update their selling prices on a regular basis. You can also see when the product price was last updated by the <span>SELLER</span>. You can use the pricing from these <span>SELLERS</span> and use it to make your proposal to your client. </h5>
                            <h5>This feature helps you to be more independent when you are working hard to generate business.</h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[14]} header=' 15. I am a SELLER. I have many products. I want to assign each product to different sales team members as they are trained to handle the technical and sales aspects of these products. How can ProcEzy help me?'>
                            <h5>At ProcEzy you can create different <span>SELLER-AGENTS</span> and assign different products to them based on <span>PRODUCT CATEGORY</span> or <span>PRODUCT SKU</span>. When a <span>BUYER</span> sends an enquiry for a product to your organization, the ProcEzy system checks for the <span>SELLER-AGENT</span> who has been assigned that particular product. It then routes the incoming enquiry or order to the <span>SELLER-AGENT</span> for further actions or order execution. You, as the <span>ADMIN</span> of the <span>SELLER ORGANIZATION</span>, can see all
                                enquiries, orders and chats received by and made by your <span>SELLER-AGENTS</span>. This will help you to remain aware and monitor your <span>SALES TEAM</span> effectively. </h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[15]} header='16. I am a SELLER. I want to ensure that I can intervene in an ongoing PRODUCT-ENQUIRY between a BUYER and my SELLER-AGENT and help my SELLER-AGENT to close the deal. Does ProcEzy have the feature to help me with this?'>
                            <h5>Yes, as an <span>ADMIN</span>, you can look into every enquiry and chat – Ongoing or Past chats – and intervene, by typing in your response to the <span>BUYER</span> in the <span>LIVE CHAT</span>. Your chat will be clearly identified by your username and your <span>SELLER-AGENT</span> and the <span>BUYER</span> will be able to read the <span>CHAT</span> messages posted by you.</h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[16]} header='17. How long does the registration process take?'>
                            <h5>The registration process is a simple and straightforward process. It takes approximately 5 to 10 minutes to enter the required details and submit them.  </h5>
                        </ExpansionPanel>
                        <ExpansionPanel {...panels[17]} header='18. What information am I expected to furnish at registration?'>

                            <ul>
                                <h6><li>1. Organization Legal Name</li></h6>
                                <h6><li>2. Organization Address </li></h6>
                                <ul>
                                    <h6><li>a. Bill To address </li></h6>
                                    <h6><li>b. Ship To address</li></h6>
                                </ul>
                                <h6><li>3. Organization GST Number </li></h6>
                                <h6><li>4. Organization PAN Number </li></h6>
                                <h6><li>5. Organization GST Certificate in PDF / Image file less than 2 MB size</li></h6>
                                <h6><li>6. Organization PAN Card in PDF / Image file less than 2 MB size</li></h6>
                                <h6><li>7. Contact Person Name</li></h6>
                                <h6><li>8. Contact Person Email address and mobile phone number </li></h6>
                            </ul>
                            <h6>Once you submit these details, your registration will be reviewed by the ProcEzy admin team and within 24 hours, you should be able to get started on ProcEzy. </h6>
                        </ExpansionPanel>
                    </ExpansionList>
                    <link
                        rel="stylesheet"
                        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
                    />
                </div>
            </div>
        </div>
    )
}

export default FAQs;