import React, { useEffect } from 'react';
import './index.scss';

const ReturnPolicy = (props) => {

    useEffect(() => {
        document.title = props.title;

        return () => {
            console.log('This will be logged on unmount');
        };
    }, []);


    return (
        <div>
            <div className='return'>
                <div className='return__container'>
                    <h6>Updated on 15th December 2022</h6>
                    <h1 className='return__heading'>RETURN POLICY</h1>
                    <div className='return__content'>
                        <h2>Returns</h2>
                        <h4>Returns is a scheme provided by respective sellers directly. The option of exchange, replacement and/ or refund is offered by the respective sellers to you. ProcEzy bears no assurance, liability or indemnity against any non-fulfilment by any seller.</h4>
                        <h4>All products listed under a particular category may not have the same returns policy. For all products, the returns/replacement policy provided on the product page shall prevail over the general returns policy. Do refer the respective item's applicable return/replacement policy on the product page for any exceptions to this returns policy.</h4>
                        <h4>We shall not assume any liability for any failure on the part of the Seller to resolve the Return Request raised by the Buyer. You also accept and agree to be bound by any amendments, updates and modifications to the policy as maybe amended, updated and modified from time to time.</h4>
                        <h4>We encourage the Buyer to review the listing before making the purchase decision. In case Buyer orders a wrong item, the Buyer may refer to the respective return/refund policy or connect with the Seller or its representatives for any return/refund.</h4>
                        <h4>Buyer needs to raise the return request within the return period applicable to the respective product.</h4>
                        <ul>
                            <h4>Following situations may arise where buyer may raise a return request:</h4>
                            <li>1.	Item was defective or damaged.</li>
                            <li>2.	Item was damaged during the Shipping.</li>
                            <li>3.	Part of the Order/ Products is found to be missing due to reasons attributable to the Seller.</li>
                            <li>4.	Wrong item was sent by the Seller.</li>
                            <li>5.	Delay in Shipment by the Seller.</li>
                        </ul>
                        <h4>At the time of making a Return Request on the Platform, Buyer will be required to provide appropriate supporting documentation/ proof including without limitation:</h4>
                        <ul>
                            <li>1.	Images of the Product indicating the issue in the Product/ shipment delivered. The images need to capture the following: </li>
                            <ul>
                                <li>(a) The shipping label with Order ID,</li>
                                <li>(b) Order details,</li>
                                <li>(c) Packed shipment, </li>
                                <li>(d) Issue observed by the Buyer in the Product,</li>
                                <li>(e) Damages to the Product.</li>
                            </ul>
                            <li>2.	Copy of bill/ tax invoice for the Product received.</li>
                        </ul>
                        <h4>Upon receipt of a Return Request from the Buyer, the same will be displayed on the Platform. Any Return Request raised by the Buyer shall be notified to the Seller for further action. Any updates on the Return Request raised by the Buyer will be communicated to the Buyer directly by the Seller either through our platform or directly as the case may be. The Seller however shall be encouraged to use the platform to enhance user experience.</h4>

                        <h2>Replacement</h2>
                        <h4>Replacement is the action or process of replacing something in place of another. A Buyer can request for replacement whenever he is not happy with the item, reason being damaged in shipping, Defective item, Item(s) missing, wrong item shipped and the like.</h4>

                        <h2>Points to be noted:</h2>
                        <h4>Buyer needs to raise the replacement request within the return period applicable to the respective product. Buyer has raised a replacement request by contacting Us on the Platform. Once the replacement request has been raised, the following steps shall be followed:</h4>
                        <ul>
                            <li>1.	Buyer is asked for "Reason for Return".</li>
                            <li>2.	An intimation shall be provided to Seller seeking either "approval" or "rejection" of the replacement request.</li>
                        </ul>
                        <h4>In case the Seller accepts the replacement request, Buyer shall be required to return the product to the Seller and only after return of the product, Seller shall be obliged to provide the replacement product to the Buyer.</h4>
                        <h4>In case Seller rejects the replacement request, Buyer can choose to raise a dispute by contacting us.</h4>
                        <h4>In case the Seller doesn't have the product at all, Seller can provide the refund to the Buyer and Buyer shall be obligated to accept the refund in lieu of replacement. All the product parameters shall be required to be complied with in cases of replacement.</h4>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ReturnPolicy;