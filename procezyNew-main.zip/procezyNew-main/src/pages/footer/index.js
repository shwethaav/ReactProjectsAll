import React from 'react';
import './index.scss';
import logo from '../../assets/images/logo.png';
// import { useHistory } from 'react-router-dom';
import { HashLink } from 'react-router-hash-link';
import { Link } from 'react-router-dom';

const Footer = () => {
    // const history = useHistory();

    const handleClickScroll = () => {
        // history.push('/')
        // window.location.reload();
        window.scrollTo(0, 0);
    };

    // const handleAboutUs = () => {
    //     history.push('/FAQs')
    //     window.location.reload();
    // };

    // const handleClickHome = () => {
    //     history.push('/')
    //     window.location.reload();
    //     window.scrollTo(0, 0);
    // };


    return (
        <div>
            <div className='footer'>
                <div className='footer__container'>
                    <div className='footer__image'>
                        <Link to='/'>
                            <img src={logo} alt='' />
                        </Link>
                    </div>
                    <div className='footer__section'>
                        <div className='footer__left'>
                            <ul>
                                <li><Link to='/terms-and-conditions' onClick={handleClickScroll}>Terms and Conditions</Link></li>
                                <li><Link to='/privacy-policy' onClick={handleClickScroll}>Privacy Policy</Link></li>
                                <li><Link to='/return-policy' onClick={handleClickScroll}>Return Policy</Link></li>
                                <li><Link to='/disclaimer' onClick={handleClickScroll}>Disclaimer</Link></li>
                            </ul>
                        </div>
                        <div className='footer__right'>
                            <div className='footer__right1'>
                                <ul>
                                    <li style={{ cursor: 'pointer' }}>
                                        <Link to='/faqs' onClick={handleClickScroll}>FAQs</Link>
                                        {/* <a>FAQs</a> */}
                                    </li>
                                    <li>
                                        <HashLink smooth to='/#contact-us' style={{ cursor: 'pointer' }}>
                                            Contact Us
                                        </HashLink>
                                        {/* <Link to='/#contact-us'>Contact Us</Link> */}
                                        {/* <HashLink smooth to='#contact-us' style={{ cursor: 'pointer' }}>Contact Us</HashLink> */}
                                    </li>
                                    <li>
                                        <a>Podcast</a>
                                    </li>
                                    <li><a href='https://www.linkedin.com/company/procezy/about/?viewAsMember=true'>Linkedin</a>
                                    </li>
                                </ul>
                            </div>
                            <div className='footer__right2'>
                                <ul>
                                    <li><a>Sign up</a></li>
                                    <li><a>Login</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <h6>&#169; ProcEzy Technologies Private Limited</h6>
                </div>
            </div>
        </div>
    )
}

export default Footer;