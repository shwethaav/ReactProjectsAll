import React, { useEffect } from 'react';
import './index.scss';

const Disclaimer = (props) => {

    useEffect(() => {
        document.title = props.title;

        return () => {
            console.log('This will be logged on unmount');
        };
    }, []);


    return (
        <div>
            <div className='dis'>
                <div className='dis__container'>
                    <h6>Updated on 15th December 2022</h6>
                    <h1 className='dis__heading'>DISCLAIMER OF WARRANTIES AND LIABILITIES</h1>
                    <div className='dis__content'>
                        <h4>a)	Except as otherwise expressly stated on the Website, all Products/Services offered on the Website are offered on an "as is" basis without any warranty whatsoever, either express or implied.</h4>
                        <h4>b)	The Company/Website makes no representations, express or implied, including without limitation, implied warranties of merchantability and fitness of a product for a particular purpose or non-infringement.</h4>
                        <h4>c)	The Company is, therefore, not responsible for, and expressly disclaims all liability for, damages of any kind arising out of use of the Website, reference to, or reliance on any information contained and/or collected in the Website. While the information contained within the Website is periodically updated, the Company gives no guarantee that the information provided in this Website is correct, complete, and up-to-date. Nothing on the Website shall be considered an endorsement, representation or warranty with respect to any user or third party, whether in regard to its contents, information, services or otherwise.</h4>
                        <h4>d)	Further, although the Company is committed towards protecting the privacy of its users, but the Company cannot ensure or warrant the security of any information you transmit to us. As a user of the Website you agree and acknowledge that under no circumstances the Company/Website shall be liable to its users and/or any person claiming through such users and/or any third party(ies) for any action, suit, losses, cost, expenses or damage which is indirect, incidental, consequential, special or exemplary, or liabilities to third parties arising from any source. The users assume all responsibility and risk for using/accessing the Website.</h4>
                        <h4>e)	The User agrees and undertakes that he/she is accessing the Website and transacting at his/her sole risk and are that he/she is using his/her best and prudent judgment before purchasing any Product/Service listed on the Website, or accessing/using any information displayed thereon. </h4>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Disclaimer;