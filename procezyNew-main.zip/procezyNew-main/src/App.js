// import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './pages/header';
import Footer from './pages/footer';
import Home from './pages/home';
import FAQs from './pages/faqs';
import TermsAndConditions from './pages/terms-And-conditions';
import Disclaimer from './pages/disclaimer';
import PrivacyPolicy from './pages/privacy';
import ReturnPolicy from './pages/return-policy';

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path='/' element={<Home title='ProcEzy | IT - Marketplace'/>} />
        <Route path='/faqs' element={<FAQs title='ProcEzy | FAQs'/>} />
        <Route path='/terms-and-conditions' element={<TermsAndConditions title='ProcEzy | Terms and Conditions'/>} />
        <Route path='/disclaimer' element={<Disclaimer title='ProcEzy | Disclaimer'/>} />
        <Route path='/privacy-policy' element={<PrivacyPolicy title='ProcEzy | Privacy Policy'/>} />
        <Route path='/return-policy' element={<ReturnPolicy title='ReturnPolicy | Return Policy'/>} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
